package com.example.demo.dao
import com.example.demo.model.FacturaDetalleProducto
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.*
@Repository
interface FacturaDetalleProductoRepository:JpaRepository<FacturaDetalleProducto,Long> {
    fun findBycodigoProducto(codigoProducto:Int):Optional<FacturaDetalleProducto>
}
