package com.example.demo.model

import javax.persistence.*

@Entity
@Table(name = "servicio")
data class Servicio(val nombreServicio: String = "",val descripcion: String = ""){
    @Id
    var codigoServicio: Long = 0

}
