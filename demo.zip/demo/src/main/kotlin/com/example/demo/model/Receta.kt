package com.example.demo.model
import java.sql.Time
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import javax.persistence.*

@Entity
@Table(name = "receta")
data class Receta(val medicamento: String = "",val indicaciones: String = "", val codigoCita:Int = 0){
    @Id
    var codigoReceta: Long = 0

}
