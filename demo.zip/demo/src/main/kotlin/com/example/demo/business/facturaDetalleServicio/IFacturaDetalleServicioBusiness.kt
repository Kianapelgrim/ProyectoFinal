package com.example.demo.business.citaDetalleProducto
import com.example.demo.model.FacturaDetalleServicio

interface IFacturaDetalleServicioBusiness {
    fun getFacturaDetalleServicios():List<FacturaDetalleServicio>
    fun getFacturaDetalleServicioById(idFacturaDetalleServicio: Long): FacturaDetalleServicio
    fun saveFacturaDetalleServicio (facturaDetalleServicio: FacturaDetalleServicio): FacturaDetalleServicio
    fun saveFacturaDetalleServicios(facturaDetalleServicio: List<FacturaDetalleServicio>): List<FacturaDetalleServicio>
    fun removeFacturaDetalleServicio(idFacturaDetalleServicio: Long)
    fun getByCodigoServicio(codigoServicio: Int): FacturaDetalleServicio
    fun updateFacturaDetalleServicio(facturaDetalleServicio: FacturaDetalleServicio): FacturaDetalleServicio

}