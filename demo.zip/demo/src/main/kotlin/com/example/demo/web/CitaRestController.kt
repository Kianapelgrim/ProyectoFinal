package com.example.demo.web

import com.example.demo.business.cita.ICitaBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Cita
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_CITAS)
class CitaRestController {
    @Autowired
    val citaBusiness:ICitaBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<Cita>>{
        return try {
            ResponseEntity(citaBusiness!!.getCitas(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idCita: Long):ResponseEntity<Cita>{
        return try {
            ResponseEntity(citaBusiness!!.getCitaById(idCita),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/estado/{estado}")
    fun loadByNombre(@PathVariable("estado")estado: String):ResponseEntity<Cita>{
        return try {
            ResponseEntity(citaBusiness!!.getByEstado(estado),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addCita")
    fun insert(@RequestBody cita: Cita):ResponseEntity<Any>{
        return try {
            citaBusiness!!.saveCita(cita)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_CITAS+"/"+cita.codigoCita)
            ResponseEntity(cita,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addCitas")
    fun insert(@RequestBody cita: List<Cita>):ResponseEntity<Any>{
        return try {
            ResponseEntity(citaBusiness!!.saveCitas(cita),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody cita: Cita):ResponseEntity<Any>{
        return try {
            citaBusiness!!.updateCita(cita)
            ResponseEntity(cita,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idCita: Long):ResponseEntity<Any>{
        return try {
            citaBusiness!!.removeCita(idCita)
            ResponseEntity(idCita,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}