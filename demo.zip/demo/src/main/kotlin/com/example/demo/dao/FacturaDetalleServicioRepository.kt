package com.example.demo.dao
import com.example.demo.model.FacturaDetalleServicio
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.*
@Repository
interface FacturaDetalleServicioRepository:JpaRepository<FacturaDetalleServicio,Long> {
    fun findBycodigoServicio(codigoServicio:Int):Optional<FacturaDetalleServicio>
}
