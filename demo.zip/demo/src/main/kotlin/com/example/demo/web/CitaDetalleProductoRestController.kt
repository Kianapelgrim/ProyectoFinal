package com.example.demo.web

import com.example.demo.business.citaDetalleProducto.ICitaDetalleProductoBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.CitaDetalleProducto
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_CITADETALLEPRODUCTOS)
class CitaDetalleProductoRestController {
    @Autowired
    val citaDetalleProductoBusiness:ICitaDetalleProductoBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<CitaDetalleProducto>>{
        return try {
            ResponseEntity(citaDetalleProductoBusiness!!.getCitaDetalleProductos(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idCitaDetalleProducto: Long):ResponseEntity<CitaDetalleProducto>{
        return try {
            ResponseEntity(citaDetalleProductoBusiness!!.getCitaDetalleProductoById(idCitaDetalleProducto),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/codigoServicio/{codigoServicio}")
    fun loadByNombre(@PathVariable("codigoServicio")codigoServicio: Int):ResponseEntity<CitaDetalleProducto>{
        return try {
            ResponseEntity(citaDetalleProductoBusiness!!.getByCodigoServicio(codigoServicio),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addCitaDetalleProducto")
    fun insert(@RequestBody citaDetalleProducto: CitaDetalleProducto):ResponseEntity<Any>{
        return try {
            citaDetalleProductoBusiness!!.saveCitaDetalleProducto(citaDetalleProducto)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_CITADETALLEPRODUCTOS+"/"+citaDetalleProducto.codigoCita)
            ResponseEntity(citaDetalleProducto,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addCitaDetalleProductos")
    fun insert(@RequestBody citaDetalleProducto: List<CitaDetalleProducto>):ResponseEntity<Any>{
        return try {
            ResponseEntity(citaDetalleProductoBusiness!!.saveCitaDetalleProductos(citaDetalleProducto),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody citaDetalleProducto: CitaDetalleProducto):ResponseEntity<Any>{
        return try {
            citaDetalleProductoBusiness!!.updateCitaDetalleProducto(citaDetalleProducto)
            ResponseEntity(citaDetalleProducto,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idCitaDetalleProducto: Long):ResponseEntity<Any>{
        return try {
            citaDetalleProductoBusiness!!.removeCitaDetalleProducto(idCitaDetalleProducto)
            ResponseEntity(idCitaDetalleProducto,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}