package com.example.demo.web
import com.example.demo.business.IServicioBusiness
import com.example.demo.business.receta.IRecetaBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Receta
import com.example.demo.model.Servicio
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_SERVICIOS)
class ServicioRestController {
    @Autowired
    val servicioBusiness:IServicioBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<Servicio>>{
        return try {
            ResponseEntity(servicioBusiness!!.getServicios(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idServicio: Long):ResponseEntity<Servicio>{
        return try {
            ResponseEntity(servicioBusiness!!.getServicioById(idServicio),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/nombreServicio/{nombreServicio}")
    fun loadByNombre(@PathVariable("nombreServicio")nombreServicio: String):ResponseEntity<Servicio>{
        return try {
            ResponseEntity(servicioBusiness!!.getServicioByNombre(nombreServicio),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addServicio")
    fun insert(@RequestBody servicio: Servicio):ResponseEntity<Any>{
        return try {
            servicioBusiness!!.saveServicio(servicio)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_SERVICIOS+"/"+servicio.codigoServicio)
            ResponseEntity(servicio,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addServicios")
    fun insert(@RequestBody servicio: List<Servicio>):ResponseEntity<Any>{
        return try {
            ResponseEntity(servicioBusiness!!.saveServicios(servicio),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody servicio: Servicio):ResponseEntity<Any>{
        return try {
            servicioBusiness!!.updateServicio(servicio)
            ResponseEntity(servicio,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idServicio: Long):ResponseEntity<Any>{
        return try {
            servicioBusiness!!.removeServicio(idServicio)
            ResponseEntity(idServicio,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}