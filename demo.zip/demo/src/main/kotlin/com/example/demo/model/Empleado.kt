package com.example.demo.model
import java.time.LocalDate
import javax.persistence.*
@Entity
@Table(name = "empleados")
data class Empleado(val nombre: String = "", val apellido: String = "",val telefono: Long = 0,
                     val identificacion: Long = 0,val puesto: String = "",val fechaNacimiento:LocalDate?=null,
                      val correo: String = "",val fechaInicio:LocalDate?=null,val contraseña: String = "",
                      val codigoDireccion: Int = 0){
    @Id
    var codigoEmpleado: Long = 0

}
