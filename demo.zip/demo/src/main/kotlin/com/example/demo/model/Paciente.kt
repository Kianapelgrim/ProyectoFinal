package com.example.demo.model

import java.time.LocalDate
import javax.persistence.*
@Entity
@Table(name = "pacientes")
data class Paciente(val nombre: String = "",val apellido: String = "", val telefono: Long = 0,
                    val email: String = "",val codigoDireccion: Long = 0, val fechaDeRegistro:LocalDate?=null,
                    val fechaDeNacimiento:LocalDate?=null){
    @Id
    var codigoPaciente: Long = 0

}
