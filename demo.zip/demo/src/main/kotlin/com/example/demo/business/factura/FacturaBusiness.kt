package com.example.demo.business.factura
import com.example.demo.dao.FacturaRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Factura
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class FacturaBusiness: IFacturaBusiness {
    @Autowired
    val facturaRepository:FacturaRepository?=null
    @Throws(BusinessException::class)
    override fun getFacturas(): List<Factura> {
        try{
            return facturaRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getFacturaById(idFactura: Long): Factura {
        val opt:Optional<Factura>
        try{
            opt = facturaRepository!!.findById(idFactura)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la factura $idFactura")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveFactura(factura: Factura): Factura {
        try{
            if (factura.cai.length<5)
                throw BusinessException("Ingrese un cai de mas de 5 caracteres")
            return  facturaRepository!!.save(factura)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveFacturas(factura: List<Factura>): List<Factura> {
        try{
            return facturaRepository!!.saveAll(factura)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeFactura(idFactura: Long) {
        val opt:Optional<Factura>
        try{
            opt = facturaRepository!!.findById(idFactura)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la Factura $idFactura")
        }else{
            try{
                facturaRepository!!.deleteById(idFactura)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getBycai(cai: String): Factura {
        val opt:Optional<Factura>
        try{
            opt = facturaRepository!!.findBycai(cai)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la factura $cai")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateFactura(factura: Factura): Factura {
        val opt:Optional<Factura>
        try{
            opt = facturaRepository!!.findById(factura.codigoFactura)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la factura ${factura.codigoFactura}")
        }else{
            try{
                return  facturaRepository!!.save(factura)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}