package com.example.demo.dao
import com.example.demo.model.CitaDetalleProducto
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.*
@Repository
interface CitaDetalleProductoRepository:JpaRepository<CitaDetalleProducto,Long> {
    fun findBycodigoServicio(codigoServicio:Int):Optional<CitaDetalleProducto>
}
