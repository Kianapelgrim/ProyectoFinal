package com.example.demo.utils

class Constants {
    companion object{
        private const val URL_API_BASE ="/api"
        private const val URL_API_VERSION ="/v1"
        private const val URL_BASE = URL_API_BASE + URL_API_VERSION
        const val URL_BASE_PERSONAS = "$URL_BASE/personas"
        const val URL_BASE_PRODUCTOS = "$URL_BASE/productos"
        const val URL_BASE_CLINICAS = "$URL_BASE/clinicas"
        const val URL_BASE_DIRECCIONS = "$URL_BASE/direccions"
        const val URL_BASE_EMPLEADOS = "$URL_BASE/empleados"
        const val URL_BASE_PACIENTES = "$URL_BASE/pacientes"
        const val URL_BASE_CITAS = "$URL_BASE/citas"
        const val URL_BASE_RECETAS = "$URL_BASE/recetas"
        const val URL_BASE_FACTURAS = "$URL_BASE/facturas"
        const val URL_BASE_SERVICIOS = "$URL_BASE/servicios"
        const val URL_BASE_CITADETALLEPRODUCTOS = "$URL_BASE/citaDetalleProductos"
        const val URL_BASE_FACTURADETALLESERVICIOS = "$URL_BASE/facturaDetalleServicios"
        const val URL_BASE_FACTURADETALLEPRODUCTOS = "$URL_BASE/facturaDetalleProductos"








    }
}