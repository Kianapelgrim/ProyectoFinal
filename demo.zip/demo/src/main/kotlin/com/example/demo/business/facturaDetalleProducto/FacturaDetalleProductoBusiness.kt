package com.example.demo.business.facturaDetalleProducto
import com.example.demo.business.citaDetalleProducto.IFacturaDetalleProductoBusiness
import com.example.demo.dao.FacturaDetalleProductoRepository
import com.example.demo.dao.FacturaDetalleServicioRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.CitaDetalleProducto
import com.example.demo.model.FacturaDetalleProducto
import com.example.demo.model.FacturaDetalleServicio
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class FacturaDetalleProductoBusiness: IFacturaDetalleProductoBusiness {
    @Autowired
    val facturaDetalleProductoRepository: FacturaDetalleProductoRepository?=null
    @Throws(BusinessException::class)
    override fun getFacturaDetalleProductos(): List<FacturaDetalleProducto> {
        try{
            return facturaDetalleProductoRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getFacturaDetalleProductoById(idFacturaDetalleProducto: Long): FacturaDetalleProducto {
        val opt:Optional<FacturaDetalleProducto>
        try{
            opt = facturaDetalleProductoRepository!!.findById(idFacturaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleProducto $idFacturaDetalleProducto")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveFacturaDetalleProducto(facturaDetalleProducto: FacturaDetalleProducto): FacturaDetalleProducto {
        try{

          if (validaciones(facturaDetalleProducto)!=null){
              throw BusinessException(validaciones(facturaDetalleProducto))
          }
            return  facturaDetalleProductoRepository!!.save(facturaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveFacturaDetalleProductos(facturaDetalleProducto: List<FacturaDetalleProducto>): List<FacturaDetalleProducto> {
        try{
            return facturaDetalleProductoRepository!!.saveAll(facturaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeFacturaDetalleProducto(idFacturaDetalleProducto: Long) {
        val opt:Optional<FacturaDetalleProducto>
        try{
            opt = facturaDetalleProductoRepository!!.findById(idFacturaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleProducto $idFacturaDetalleProducto")
        }else{
            try{
                facturaDetalleProductoRepository!!.deleteById(idFacturaDetalleProducto)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getByCodigoProducto(codigoProducto: Int): FacturaDetalleProducto {
        val opt:Optional<FacturaDetalleProducto>
        try{
            opt = facturaDetalleProductoRepository!!.findBycodigoProducto(codigoProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleProducto $codigoProducto")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateFacturaDetalleProducto(facturaDetalleProducto: FacturaDetalleProducto): FacturaDetalleProducto {
        val opt:Optional<FacturaDetalleProducto>
        try{
            opt = facturaDetalleProductoRepository!!.findById(facturaDetalleProducto.codigoFactura)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleProducto ${facturaDetalleProducto.codigoFactura}")
        }else{

            try{
                return  facturaDetalleProductoRepository!!.save(facturaDetalleProducto)
            }catch (e:Exception){
                throw BusinessException(e.message);

            }

        }
        return opt.get()
    }
    fun validaciones (facturaDetalleProducto: FacturaDetalleProducto): String? {
        var message: String? = null
        if (facturaDetalleProducto.codigoProducto==0){
            message= "Ingrese un codigo de producto distinto a 0"
        }

        return message
        }

}