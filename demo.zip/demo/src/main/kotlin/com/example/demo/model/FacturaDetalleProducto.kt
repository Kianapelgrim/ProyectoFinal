package com.example.demo.model
import javax.persistence.*

@Entity
@Table(name = "FacturaDetalleProducto")
data class FacturaDetalleProducto(val codigoProducto: Int = 0,val cantidadProducto: Int = 0){
    @Id
    var codigoFactura: Long = 0
}
