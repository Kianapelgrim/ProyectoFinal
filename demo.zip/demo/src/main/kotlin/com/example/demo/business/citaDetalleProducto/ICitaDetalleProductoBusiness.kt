package com.example.demo.business.citaDetalleProducto
import com.example.demo.model.CitaDetalleProducto

interface ICitaDetalleProductoBusiness {
    fun getCitaDetalleProductos():List<CitaDetalleProducto>
    fun getCitaDetalleProductoById(idCitaDetalleProducto: Long): CitaDetalleProducto
    fun saveCitaDetalleProducto (citaDetalleProducto: CitaDetalleProducto): CitaDetalleProducto
    fun saveCitaDetalleProductos(citaDetalleProducto: List<CitaDetalleProducto>): List<CitaDetalleProducto>
    fun removeCitaDetalleProducto(idCitaDetalleProducto: Long)
    fun getByCodigoServicio(codigoServicio: Int): CitaDetalleProducto
    fun updateCitaDetalleProducto(citaDetalleProducto: CitaDetalleProducto): CitaDetalleProducto

}