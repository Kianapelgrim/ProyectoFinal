package com.example.demo.business.paciente
import com.example.demo.business.direccion.IEmpleadoBusiness
import com.example.demo.business.direccion.IPacienteBusiness
import com.example.demo.dao.EmpleadoRepository
import com.example.demo.dao.PacienteRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Empleado
import com.example.demo.model.Paciente
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.awt.PaintContext
import java.time.Instant.now
import java.time.LocalDate
import java.util.*
import kotlin.jvm.Throws

@Service
class PacienteBusiness: IPacienteBusiness {
    @Autowired
    val pacienteRepository:PacienteRepository?=null
    @Throws(BusinessException::class)
    override fun getPacientes(): List<Paciente> {
        try{
            return pacienteRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getPacienteById(idPaciente: Long): Paciente {
        val opt:Optional<Paciente>
        try{
            opt = pacienteRepository!!.findById(idPaciente)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el paciente $idPaciente")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun savePaciente(paciente: Paciente): Paciente {
        try{
            if (validaciones(paciente)!=null){
                throw BusinessException(validaciones(paciente))
            }
            return  pacienteRepository!!.save(paciente)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun savePacientes(paciente: List<Paciente>): List<Paciente> {
        try{
            return pacienteRepository!!.saveAll(paciente)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removePaciente(idPaciente: Long) {
        val opt:Optional<Paciente>
        try{
            opt = pacienteRepository!!.findById(idPaciente)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el paciente $idPaciente")
        }else{
            try{
                pacienteRepository!!.deleteById(idPaciente)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getByNombrePaciente(nombrePaciente: String): Paciente {
        val opt:Optional<Paciente>
        try{
            opt = pacienteRepository!!.findByNombre(nombrePaciente)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el paciente $nombrePaciente")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updatePaciente(paciente: Paciente): Paciente {
        val opt:Optional<Paciente>
        try{
            opt = pacienteRepository!!.findById(paciente.codigoPaciente)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el paciente ${paciente.codigoPaciente}")
        }else{
            try{
                if (validaciones(paciente)!=null){
                throw BusinessException(validaciones(paciente))
            }
                return  pacienteRepository!!.save(paciente)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }
    fun validaciones(paciente: Paciente):String?{
        var now: LocalDate = LocalDate.now()
        var message :String? = null
        if (paciente.nombre==null){
            message="Ingrese un Nombre"
        }
        if (paciente.apellido==null){
            message="Ingrese un Apellido"
        }
        if (paciente.telefono==null){
            message="Ingrese un Telefono"
        }
        if (paciente.email.isNullOrBlank()){
            message="Ingrese un email"
        }
        if (paciente.codigoDireccion==null){
            message="Ingrese un codigo de Direccion"
        }
        if (paciente.fechaDeRegistro==null){
            message="Ingrese un fecha de Registro"
        }
        if (paciente.fechaDeNacimiento==null){
            message="Ingrese un fecha de Nacimiento"
        }else if (paciente.fechaDeNacimiento!!.isAfter(now)){
            message="Ingrese una fecha correcta"
        }
        if (paciente.telefono<=9999999||paciente.telefono>100000000){
        message="Ingrese un número telefónico válido"
        }

        return message
    }

}