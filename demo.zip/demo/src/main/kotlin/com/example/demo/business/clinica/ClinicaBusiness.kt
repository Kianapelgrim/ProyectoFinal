package com.example.demo.business
import com.example.demo.dao.ClinicaRepository
import com.example.demo.dao.PersonaRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Clinica
import com.example.demo.model.Persona
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class ClinicaBusiness: IClinicaBussiness {
    @Autowired
    val clinicaRepository: ClinicaRepository?=null
    @Throws(BusinessException::class)
    override fun getClinicas(): List<Clinica> {
        try{
            return clinicaRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getClinicaById(idClinica: Long): Clinica {
        val opt:Optional<Clinica>
        try{
            opt = clinicaRepository!!.findById(idClinica)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la clinica $idClinica")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveClinica(clinica: Clinica): Clinica {
        try{
            if (clinica.nombreClinica.length<5)
                throw BusinessException("Ingrese en el nombre de la clinica mas de 5 caracteres")
            return  clinicaRepository!!.save(clinica)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveClinicas(clinicas: List<Clinica>): List<Clinica> {
        try{
            return clinicaRepository!!.saveAll(clinicas)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeClinica(idClinica: Long) {
        val opt:Optional<Clinica>
        try{
            opt = clinicaRepository!!.findById(idClinica)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la clinica $idClinica")
        }else{
            try{
                clinicaRepository!!.deleteById(idClinica)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getClinicaByNombre(nombreClinica: String): Clinica {
        val opt:Optional<Clinica>
        try{
            opt = clinicaRepository!!.findByNombreClinica(nombreClinica)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la clinica $nombreClinica")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateClinica(clinica: Clinica): Clinica {
        val opt:Optional<Clinica>
        try{
            opt = clinicaRepository!!.findById(clinica.codigoClinica)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la clinica ${clinica.codigoClinica}")
        }else{
            try{
                return  clinicaRepository!!.save(clinica)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}