package com.example.demo.exceptions

import java.lang.Exception

class NotFoundException(message:String?): Exception(message) {
}