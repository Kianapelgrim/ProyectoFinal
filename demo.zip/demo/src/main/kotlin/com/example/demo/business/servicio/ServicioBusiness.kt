package com.example.demo.business.factura
import com.example.demo.business.IServicioBusiness
import com.example.demo.dao.ServicioRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Servicio
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class ServicioBusiness: IServicioBusiness {
    @Autowired
    val servicioRepository:ServicioRepository?=null
    @Throws(BusinessException::class)
    override fun getServicios(): List<Servicio> {
        try{
            return servicioRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getServicioById(idServicio: Long): Servicio {
        val opt:Optional<Servicio>
        try{
            opt = servicioRepository!!.findById(idServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Servicio $idServicio")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveServicio(servicio: Servicio): Servicio {
        try{
            if (servicio.nombreServicio.length<5)
                throw BusinessException("Ingrese un nombre de servicio de mas de 5 caracteres")
            return  servicioRepository!!.save(servicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveServicios(servicio: List<Servicio>): List<Servicio> {
        try{
            return servicioRepository!!.saveAll(servicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeServicio(idServicio: Long) {
        val opt:Optional<Servicio>
        try{
            opt = servicioRepository!!.findById(idServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Servicio $idServicio")
        }else{
            try{
                servicioRepository!!.deleteById(idServicio)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getServicioByNombre(nombreServicio: String): Servicio {
        val opt:Optional<Servicio>
        try{
            opt = servicioRepository!!.findByNombreServicio(nombreServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Servicio $nombreServicio")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateServicio(servicio: Servicio): Servicio {
        val opt:Optional<Servicio>
        try{
            opt = servicioRepository!!.findById(servicio.codigoServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Servicio ${servicio.codigoServicio}")
        }else{
            try{
                return  servicioRepository!!.save(servicio)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}