package com.example.demo.business

import com.example.demo.model.Persona

interface IPersonaBussiness {
    fun getPersonas():List<Persona>
    fun getPersonaById(idPersona:Long): Persona
    fun savePersona (persona:Persona): Persona
    fun savePersonas(persona: List<Persona>): List<Persona>
    fun removePersona(idPersona: Long)
    fun getPersonaByNombre(nombrePersona: String): Persona
    fun updatePersona(persona: Persona): Persona

}