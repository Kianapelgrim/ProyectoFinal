package com.example.demo.business.factura
import com.example.demo.model.Factura


interface IFacturaBusiness {
    fun getFacturas():List<Factura>
    fun getFacturaById(idFactura: Long): Factura
    fun saveFactura (factura: Factura): Factura
    fun saveFacturas(factura: List<Factura>): List<Factura>
    fun removeFactura(idFactura: Long)
    fun getBycai(cai: String): Factura
    fun updateFactura(factura: Factura): Factura

}