package com.example.demo.exceptions

import java.lang.Exception

class BusinessException(message:String?):Exception(message)