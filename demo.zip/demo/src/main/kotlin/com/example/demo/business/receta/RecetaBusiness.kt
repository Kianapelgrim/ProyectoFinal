package com.example.demo.business.receta
import com.example.demo.dao.RecetaRepository
import com.example.demo.model.Receta
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Producto
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class RecetaBusiness: IRecetaBusiness {
    @Autowired
    val recetaRepository:RecetaRepository?=null
    @Throws(BusinessException::class)
    override fun getRecetas(): List<Receta> {
        try{
            return recetaRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getRecetaById(idReceta: Long): Receta {
        val opt:Optional<Receta>
        try{
            opt = recetaRepository!!.findById(idReceta)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la receta  $idReceta")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveReceta(receta: Receta): Receta{
        try{
            if (validaciones(receta)!=null){
                throw BusinessException(validaciones(receta))
            }
            return  recetaRepository!!.save(receta)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveRecetas(receta: List<Receta>): List<Receta> {
        try{
            return recetaRepository!!.saveAll(receta)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeReceta(idReceta: Long) {
        val opt:Optional<Receta>
        try{
            opt = recetaRepository!!.findById(idReceta)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la receta $idReceta")
        }else{
            try{
                recetaRepository!!.deleteById(idReceta)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getByMedicamento(medicamento: String): Receta {
        val opt:Optional<Receta>
        try{
            opt = recetaRepository!!.findByMedicamento(medicamento)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la receta $medicamento")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateReceta(receta: Receta): Receta {
        val opt:Optional<Receta>
        try{
            if (validaciones(receta)!=null){
                throw BusinessException(validaciones(receta))
            }
            opt = recetaRepository!!.findById(receta.codigoReceta)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la Receta ${receta.codigoReceta}")
        }else{
            try{
                return  recetaRepository!!.save(receta)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()


        } fun validaciones(receta: Receta):String?{
        var message:String? =null
        if (receta.codigoCita==null){
            message= "Ingrese un código de cita"
        }
        if (receta.codigoReceta==null){
            message= "Ingrese un código de receta"
        }
        if (receta.indicaciones==null){
            message= "Ingrese indicaciones para el medicamento"
        }
        if (receta.medicamento==null){
            message= "Ingrese un medicamento"
        }
        if (receta.codigoReceta<0){
            message= "Ingrese un código de receta válido"
        }
        if (receta.codigoCita<0){
            message= "Ingrese un código de cita válido"
        }

        return message

    }
    }
