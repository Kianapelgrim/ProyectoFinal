package com.example.demo.business.citaDetalleProducto
import com.example.demo.business.direccion.IEmpleadoBusiness
import com.example.demo.dao.CitaDetalleProductoRepository
import com.example.demo.dao.EmpleadoRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.CitaDetalleProducto
import com.example.demo.model.Empleado
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class CitaDetalleProductoBusiness: ICitaDetalleProductoBusiness {
    @Autowired
    val citaDetalleProductoRepository:CitaDetalleProductoRepository?=null
    @Throws(BusinessException::class)
    override fun getCitaDetalleProductos(): List<CitaDetalleProducto> {
        try{
            return citaDetalleProductoRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getCitaDetalleProductoById(idCitaDetalleProducto: Long): CitaDetalleProducto {
        val opt:Optional<CitaDetalleProducto>
        try{
            opt = citaDetalleProductoRepository!!.findById(idCitaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la CitaDetalleProducto $idCitaDetalleProducto")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveCitaDetalleProducto(citaDetalleProducto: CitaDetalleProducto): CitaDetalleProducto {
        try{
            if (citaDetalleProducto.codigoServicio==0)
                throw BusinessException("Ingrese un codigo de servicio distinto a 0")
            return  citaDetalleProductoRepository!!.save(citaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveCitaDetalleProductos(citaDetalleProducto: List<CitaDetalleProducto>): List<CitaDetalleProducto> {
        try{
            return citaDetalleProductoRepository!!.saveAll(citaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeCitaDetalleProducto(idCitaDetalleProducto: Long) {
        val opt:Optional<CitaDetalleProducto>
        try{
            opt = citaDetalleProductoRepository!!.findById(idCitaDetalleProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la CitaDetalleProducto $idCitaDetalleProducto")
        }else{
            try{
                citaDetalleProductoRepository!!.deleteById(idCitaDetalleProducto)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getByCodigoServicio(codigoServicio: Int): CitaDetalleProducto {
        val opt:Optional<CitaDetalleProducto>
        try{
            opt = citaDetalleProductoRepository!!.findBycodigoServicio(codigoServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la CitaDetalleProducto $codigoServicio")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateCitaDetalleProducto(citaDetalleProducto: CitaDetalleProducto): CitaDetalleProducto {
        val opt:Optional<CitaDetalleProducto>
        try{
            opt = citaDetalleProductoRepository!!.findById(citaDetalleProducto.codigoCita)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la CitaDetalleProducto ${citaDetalleProducto.codigoCita}")
        }else{
            try{
                return  citaDetalleProductoRepository!!.save(citaDetalleProducto)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}