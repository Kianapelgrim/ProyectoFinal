package com.example.demo.dao
import com.example.demo.model.Paciente
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.*
@Repository
interface PacienteRepository:JpaRepository<Paciente,Long> {
    fun findByNombre(nombrePaciente:String):Optional<Paciente>
}