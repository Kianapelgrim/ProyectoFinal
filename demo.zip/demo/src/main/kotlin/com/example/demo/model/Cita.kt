package com.example.demo.model
import java.time.LocalDate
import java.time.LocalTime
import javax.persistence.*

@Entity
@Table(name = "cita")
data class Cita(val estado: String = "", val fecha:LocalDate?=null,
                val hora: LocalTime?=null, val codigoClinica: Long = 0,
                val codigoPaciente:Int=0, val codigoEmpleado:Int = 0, val fechaDeRegistro:LocalDate?=null){
    @Id
    var codigoCita: Long = 0

}
