package com.example.demo.web

import com.example.demo.business.citaDetalleProducto.IFacturaDetalleServicioBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.FacturaDetalleProducto
import com.example.demo.model.FacturaDetalleServicio
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_FACTURADETALLESERVICIOS)
class FacturaDetalleServicioRestController {
    @Autowired
    val facturaDetalleServicioBusiness: IFacturaDetalleServicioBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<FacturaDetalleServicio>>{
        return try {
            ResponseEntity(facturaDetalleServicioBusiness!!.getFacturaDetalleServicios(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idFacturaDetalleServicio: Long):ResponseEntity<FacturaDetalleServicio>{
        return try {
            ResponseEntity(facturaDetalleServicioBusiness!!.getFacturaDetalleServicioById(idFacturaDetalleServicio),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/codigoServicio/{codigoServicio}")
    fun loadByNombre(@PathVariable("codigoServicio")codigoServicio: Int):ResponseEntity<FacturaDetalleServicio>{
        return try {
            ResponseEntity(facturaDetalleServicioBusiness!!.getByCodigoServicio(codigoServicio),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addFacturaDetalleServicio")
    fun insert(@RequestBody facturaDetalleServicio: FacturaDetalleServicio):ResponseEntity<Any>{
        return try {
            facturaDetalleServicioBusiness!!.saveFacturaDetalleServicio(facturaDetalleServicio)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_FACTURADETALLESERVICIOS+"/"+facturaDetalleServicio.codigoFactura)
            ResponseEntity(facturaDetalleServicio,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }

    @PostMapping("/addFacturaDetalleServicios")
    fun insert(@RequestBody facturaDetalleServicio: List<FacturaDetalleServicio>):ResponseEntity<Any>{
        return try {
            ResponseEntity(facturaDetalleServicioBusiness!!.saveFacturaDetalleServicios(facturaDetalleServicio),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody facturaDetalleServicio: FacturaDetalleServicio):ResponseEntity<Any>{
        return try {
            facturaDetalleServicioBusiness!!.updateFacturaDetalleServicio(facturaDetalleServicio)
            ResponseEntity(facturaDetalleServicio,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idFacturaDetalleServicio: Long):ResponseEntity<Any>{
        return try {
            facturaDetalleServicioBusiness!!.removeFacturaDetalleServicio(idFacturaDetalleServicio)
            ResponseEntity(idFacturaDetalleServicio,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}