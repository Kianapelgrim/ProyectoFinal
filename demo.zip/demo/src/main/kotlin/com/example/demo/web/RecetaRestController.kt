package com.example.demo.web
import com.example.demo.business.receta.IRecetaBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Receta
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_RECETAS)
class RecetaRestController {
    @Autowired
    val recetaBusiness:IRecetaBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<Receta>>{
        return try {
            ResponseEntity(recetaBusiness!!.getRecetas(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idReceta: Long):ResponseEntity<Receta>{
        return try {
            ResponseEntity(recetaBusiness!!.getRecetaById(idReceta),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/medicamento/{medicamento}")
    fun loadByNombre(@PathVariable("medicamento")medicamento: String):ResponseEntity<Receta>{
        return try {
            ResponseEntity(recetaBusiness!!.getByMedicamento(medicamento),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addReceta")
    fun insert(@RequestBody receta: Receta):ResponseEntity<Any>{
        return try {
            recetaBusiness!!.saveReceta(receta)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_RECETAS+"/"+receta.codigoReceta)
            ResponseEntity(receta,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addRecetas")
    fun insert(@RequestBody receta: List<Receta>):ResponseEntity<Any>{
        return try {
            ResponseEntity(recetaBusiness!!.saveRecetas(receta),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody receta: Receta):ResponseEntity<Any>{
        return try {
            recetaBusiness!!.updateReceta(receta)
            ResponseEntity(receta,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idReceta: Long):ResponseEntity<Any>{
        return try {
            recetaBusiness!!.removeReceta(idReceta)
            ResponseEntity(idReceta,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}