package com.example.demo.model

import java.time.LocalDate
import javax.persistence.*
@Entity
@Table(name = "persona")//,catalog="dbo" Si fueran catalogos
data class Persona(val dni: Long = 0, val nombre: String = "",val apellido: String = "",
                   val fechaNacimiento:LocalDate?=null){
    @Id
    //@GeneratedValue (strategy = GenerationType.AUTO) Si fuera MySql
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    var id: Long = 0

}
