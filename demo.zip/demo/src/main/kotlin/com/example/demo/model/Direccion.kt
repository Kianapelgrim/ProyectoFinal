package com.example.demo.model
import javax.persistence.*
@Entity
@Table(name = "direccion")
data class Direccion(val ciudad: String = "", val calle: String = "",val zipCode: Int = 0,
                     val departamentos: String = ""){
    @Id
    var codigoDireccion: Long = 0

}
