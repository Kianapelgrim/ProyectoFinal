package com.example.demo.business.direccion
import com.example.demo.dao.EmpleadoRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Empleado
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class EmpleadoBusiness: IEmpleadoBusiness {
    @Autowired
    val empleadoRepository:EmpleadoRepository?=null
    @Throws(BusinessException::class)
    override fun getEmpleados(): List<Empleado> {
        try{
            return empleadoRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getEmpleadoById(idEmpleado: Long): Empleado {
        val opt:Optional<Empleado>
        try{
            opt = empleadoRepository!!.findById(idEmpleado)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el empleado $idEmpleado")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveEmpleado(empleado: Empleado): Empleado {
        try{
            if (empleado.codigoEmpleado==null){
                throw BusinessException("Ingrese un codigo de Empleado")
            }
            if (empleado.nombre.length<5){
                throw BusinessException("Ingrese un nombre de mas de 5 caracteres")
            }
            if (empleado.apellido.isNullOrBlank()){
                throw BusinessException("Debe ingresar un apellido")
            }
            if (empleado.codigoDireccion==null){
                throw BusinessException("Debe ingresar un codigo de Direccion")
            }
            if (empleado.codigoEmpleado==null){
                throw BusinessException("Debe ingresar un codigo de Empleado")
            }
            if (empleado.contraseña.isNullOrBlank()){
                throw BusinessException("Debe ingresar  una Contraseña")
            }
            if (empleado.correo.isNullOrBlank()){
                throw BusinessException("Debe ingresar un Correo")
            }
            if (empleado.fechaNacimiento==null){
                throw BusinessException("Debe ingresar una Fecha de Nacimiento")
            }
            if (empleado.identificacion==null){
                throw BusinessException("Debe ingresar una Identificacion")
            }
            if (empleado.puesto.isNullOrBlank()){
                throw BusinessException("Debe ingresar un Puesto")
            }
            if (empleado.telefono==null){
                throw BusinessException("Debe ingresar un Telefono")
            }
            return  empleadoRepository!!.save(empleado)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveEmpleados(empleados: List<Empleado>): List<Empleado> {
        try{
            return empleadoRepository!!.saveAll(empleados)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeEmpleado(idEmpleado: Long) {
        val opt:Optional<Empleado>
        try{
            opt = empleadoRepository!!.findById(idEmpleado)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el empleado $idEmpleado")
        }else{
            try{
                empleadoRepository!!.deleteById(idEmpleado)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getByNombreEmpleado(nombreEmpleado: String): Empleado {
        val opt:Optional<Empleado>
        try{
            opt = empleadoRepository!!.findByNombre(nombreEmpleado)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el empleado $nombreEmpleado")
        }
        return opt.get()
    }

    override fun getByEmail(emailEmpleado: String): Empleado {
        val opt:Optional<Empleado>
        try{
            opt = empleadoRepository!!.findByCorreo(emailEmpleado)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el empleado $emailEmpleado")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateEmpleado(empleado: Empleado): Empleado {
        val opt:Optional<Empleado>
        try{
            opt = empleadoRepository!!.findById(empleado.codigoEmpleado)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el empleado ${empleado.codigoEmpleado}")
        }else{
            try{
                if (empleado.codigoEmpleado==null){
                    throw BusinessException("Ingrese un codigo de Empleado")
                }
                if (empleado.nombre.length<5){
                    throw BusinessException("Ingrese un nombre de mas de 5 caracteres")
                }
                if (empleado.apellido.isNullOrBlank()){
                    throw BusinessException("Debe ingresar un apellido")
                }
                if (empleado.codigoDireccion==null){
                    throw BusinessException("Debe ingresar un codigo de Direccion")
                }
                if (empleado.codigoEmpleado==null){
                    throw BusinessException("Debe ingresar un codigo de Empleado")
                }
                if (empleado.contraseña.isNullOrBlank()){
                    throw BusinessException("Debe ingresar  una Contraseña")
                }
                if (empleado.correo.isNullOrBlank()){
                    throw BusinessException("Debe ingresar un Correo")
                }
                if (empleado.fechaNacimiento==null){
                    throw BusinessException("Debe ingresar una Fecha de Nacimiento")
                }
                if (empleado.identificacion==null){
                    throw BusinessException("Debe ingresar una Identificacion")
                }
                if (empleado.puesto.isNullOrBlank()){
                    throw BusinessException("Debe ingresar un Puesto")
                }
                if (empleado.telefono==null){
                    throw BusinessException("Debe ingresar un Telefono")
                }
                return  empleadoRepository!!.save(empleado)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}