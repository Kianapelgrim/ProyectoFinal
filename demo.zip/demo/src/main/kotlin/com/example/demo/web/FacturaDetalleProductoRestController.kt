package com.example.demo.web

import com.example.demo.business.cita.ICitaBusiness
import com.example.demo.business.citaDetalleProducto.ICitaDetalleProductoBusiness
import com.example.demo.business.citaDetalleProducto.IFacturaDetalleProductoBusiness
import com.example.demo.business.citaDetalleProducto.IFacturaDetalleServicioBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Cita
import com.example.demo.model.CitaDetalleProducto
import com.example.demo.model.FacturaDetalleProducto
import com.example.demo.model.FacturaDetalleServicio
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_FACTURADETALLEPRODUCTOS)
class FacturaDetalleProductoRestController {
    @Autowired
    val facturaDetalleProductoBusiness: IFacturaDetalleProductoBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<FacturaDetalleProducto>>{
        return try {
            ResponseEntity(facturaDetalleProductoBusiness!!.getFacturaDetalleProductos(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idFacturaDetalleProducto: Long):ResponseEntity<FacturaDetalleProducto>{
        return try {
            ResponseEntity(facturaDetalleProductoBusiness!!.getFacturaDetalleProductoById(idFacturaDetalleProducto),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/codigoProducto/{codigoProducto}")
    fun loadByNombre(@PathVariable("codigoProducto")codigoProducto: Int):ResponseEntity<FacturaDetalleProducto>{
        return try {
            ResponseEntity(facturaDetalleProductoBusiness!!.getByCodigoProducto(codigoProducto),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addFacturaDetalleProducto")
    fun insert(@RequestBody facturaDetalleProducto: FacturaDetalleProducto):ResponseEntity<Any>{
        return try {
            facturaDetalleProductoBusiness!!.saveFacturaDetalleProducto(facturaDetalleProducto)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_FACTURADETALLEPRODUCTOS+"/"+facturaDetalleProducto.codigoFactura)
            ResponseEntity(facturaDetalleProducto,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addFacturaDetalleProductos")
    fun insert(@RequestBody facturaDetalleProducto: List<FacturaDetalleProducto>):ResponseEntity<Any>{
        return try {
            ResponseEntity(facturaDetalleProductoBusiness!!.saveFacturaDetalleProductos(facturaDetalleProducto),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody facturaDetalleProducto: FacturaDetalleProducto):ResponseEntity<Any>{
        return try {
            facturaDetalleProductoBusiness!!.updateFacturaDetalleProducto(facturaDetalleProducto)
            ResponseEntity(facturaDetalleProducto,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idFacturaDetalleProducto: Long):ResponseEntity<Any>{
        return try {
            facturaDetalleProductoBusiness!!.removeFacturaDetalleProducto(idFacturaDetalleProducto)
            ResponseEntity(idFacturaDetalleProducto,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}