package com.example.demo.business

import com.example.demo.model.Clinica

interface IClinicaBussiness {
    fun getClinicas():List<Clinica>
    fun getClinicaById(idClinica:Long): Clinica
    fun saveClinica (clinica: Clinica): Clinica
    fun saveClinicas(clinica: List<Clinica>): List<Clinica>
    fun removeClinica(idClinica: Long)
    fun getClinicaByNombre(nombreClinica: String): Clinica
    fun updateClinica(clinica: Clinica): Clinica

}