package com.example.demo.web

import com.example.demo.business.direccion.IEmpleadoBusiness
import com.example.demo.business.factura.IFacturaBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Empleado
import com.example.demo.model.Factura
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_FACTURAS)
class FacturaRestController{
    @Autowired
    val facturaBusiness:IFacturaBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<Factura>>{
        return try {
            ResponseEntity(facturaBusiness!!.getFacturas(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idFactura: Long):ResponseEntity<Factura>{
        return try {
            ResponseEntity(facturaBusiness!!.getFacturaById(idFactura),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/cai/{cai}")
    fun loadByNombre(@PathVariable("cai")cai: String):ResponseEntity<Factura>{
        return try {
            ResponseEntity(facturaBusiness!!.getBycai(cai),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addFactura")
    fun insert(@RequestBody factura: Factura):ResponseEntity<Any>{
        return try {
            facturaBusiness!!.saveFactura(factura)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_FACTURAS+"/"+factura.codigoFactura)
            ResponseEntity(factura,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addFacturas")
    fun insert(@RequestBody factura: List<Factura>):ResponseEntity<Any>{
        return try {
            ResponseEntity(facturaBusiness!!.saveFacturas(factura),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody factura: Factura):ResponseEntity<Any>{
        return try {
            facturaBusiness!!.updateFactura(factura)
            ResponseEntity(factura,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idFactura: Long):ResponseEntity<Any>{
        return try {
            facturaBusiness!!.removeFactura(idFactura)
            ResponseEntity(idFactura,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}