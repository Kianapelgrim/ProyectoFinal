package com.example.demo.business.direccion

import com.example.demo.model.Direccion


interface IDireccionBusiness {
    fun getDireccions():List<Direccion>
    fun getDireccionById(idDireccion:Long): Direccion
    fun saveDireccion (direccion: Direccion): Direccion
    fun saveDireccions(direccion: List<Direccion>): List<Direccion>
    fun removeDireccion(idDireccion: Long)
    fun getDireccionByCiudad(ciudad: String): Direccion
    fun updateDireccion(direccion: Direccion): Direccion

}