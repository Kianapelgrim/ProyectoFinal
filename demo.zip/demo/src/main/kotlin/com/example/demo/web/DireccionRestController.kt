package com.example.demo.web

import com.example.demo.business.direccion.IDireccionBusiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Direccion
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_DIRECCIONS)
class DireccionRestController {
    @Autowired
    val direccionBusiness:IDireccionBusiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<Direccion>>{
        return try {
            ResponseEntity(direccionBusiness!!.getDireccions(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idDireccion: Long):ResponseEntity<Direccion>{
        return try {
            ResponseEntity(direccionBusiness!!.getDireccionById(idDireccion),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/ciudad/{ciudad}")
    fun loadByNombre(@PathVariable("ciudad")ciudad: String):ResponseEntity<Direccion>{
        return try {
            ResponseEntity(direccionBusiness!!.getDireccionByCiudad(ciudad),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addDireccion")
    fun insert(@RequestBody direccion: Direccion):ResponseEntity<Any>{
        return try {
            direccionBusiness!!.saveDireccion(direccion)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_DIRECCIONS+"/"+direccion.codigoDireccion)
            ResponseEntity(direccion,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addDireccions")
    fun insert(@RequestBody direccion: List<Direccion>):ResponseEntity<Any>{
        return try {
            ResponseEntity(direccionBusiness!!.saveDireccions(direccion),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody direccion: Direccion):ResponseEntity<Any>{
        return try {
            direccionBusiness!!.updateDireccion(direccion)
            ResponseEntity(direccion,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idDireccion: Long):ResponseEntity<Any>{
        return try {
            direccionBusiness!!.removeDireccion(idDireccion)
            ResponseEntity(idDireccion,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}