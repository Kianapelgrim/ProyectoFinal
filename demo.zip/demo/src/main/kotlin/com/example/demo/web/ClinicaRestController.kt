package com.example.demo.web

import com.example.demo.business.IClinicaBussiness
import com.example.demo.business.IPersonaBussiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Clinica
import com.example.demo.model.Persona
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_CLINICAS)
class ClinicaRestController {
    @Autowired
    val clinicaBusiness:IClinicaBussiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<Clinica>>{
        return try {
            ResponseEntity(clinicaBusiness!!.getClinicas(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idClinica: Long):ResponseEntity<Clinica>{
        return try {
            ResponseEntity(clinicaBusiness!!.getClinicaById(idClinica),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @GetMapping ("/nombreClinica/{nombreClinica}")
    fun loadByNombre(@PathVariable("nombreClinica")nombreClinica: String):ResponseEntity<Clinica>{
        return try {
            ResponseEntity(clinicaBusiness!!.getClinicaByNombre(nombreClinica),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addClinica")
    fun insert(@RequestBody clinica: Clinica):ResponseEntity<Any>{
        return try {
            clinicaBusiness!!.saveClinica(clinica)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_CLINICAS+"/"+clinica.codigoClinica)
            ResponseEntity(clinica,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addClinicas")
    fun insert(@RequestBody clinica: List<Clinica>):ResponseEntity<Any>{
        return try {
            ResponseEntity(clinicaBusiness!!.saveClinicas(clinica),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody clinica: Clinica):ResponseEntity<Any>{
        return try {
            clinicaBusiness!!.updateClinica(clinica)
            ResponseEntity(clinica,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idClinica: Long):ResponseEntity<Any>{
        return try {
            clinicaBusiness!!.removeClinica(idClinica)
            ResponseEntity(idClinica,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}