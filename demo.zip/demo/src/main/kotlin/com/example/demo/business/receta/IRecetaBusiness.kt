package com.example.demo.business.receta
import com.example.demo.model.Cita
import com.example.demo.model.Receta

interface IRecetaBusiness {
    fun getRecetas():List<Receta>
    fun getRecetaById(idRecta: Long): Receta
    fun saveReceta (receta: Receta): Receta
    fun saveRecetas(receta: List<Receta>): List<Receta>
    fun removeReceta(idReceta: Long)
    fun getByMedicamento(medicamento: String): Receta
    fun updateReceta(receta: Receta): Receta

}