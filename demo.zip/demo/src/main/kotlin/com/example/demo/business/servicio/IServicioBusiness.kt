package com.example.demo.business
import com.example.demo.model.Servicio

interface IServicioBusiness {
    fun getServicios():List<Servicio>
    fun getServicioById(idServicio:Long): Servicio
    fun saveServicio (servicio: Servicio): Servicio
    fun saveServicios(servicio: List<Servicio>): List<Servicio>
    fun removeServicio(idServicio: Long)
    fun getServicioByNombre(nombreServicio: String): Servicio
    fun updateServicio(servicio: Servicio): Servicio

}