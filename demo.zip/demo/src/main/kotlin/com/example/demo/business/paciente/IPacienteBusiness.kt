package com.example.demo.business.direccion
import com.example.demo.model.Empleado
import com.example.demo.model.Paciente


interface IPacienteBusiness {
    fun getPacientes():List<Paciente>
    fun getPacienteById(idPaciente: Long): Paciente
    fun savePaciente (paciente: Paciente): Paciente
    fun savePacientes(paciente: List<Paciente>): List<Paciente>
    fun removePaciente(idPaciente: Long)
    fun getByNombrePaciente(nombrePaciente: String): Paciente
    fun updatePaciente(paciente: Paciente): Paciente

}