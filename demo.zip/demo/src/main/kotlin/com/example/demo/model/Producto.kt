package com.example.demo.model
import javax.persistence.*
@Entity
@Table(name = "producto")//,catalog="dbo" Si fueran catalogos
data class Producto( val nombreProducto: String = "",val descripcion: String = "",
                    val precio:Float=0.0f, val stockActual:Int = 0,val stockMinimo: Int=0,
                    val stockMaximo: Int=0){
    @Id
    var codigoProducto: Long = 0

}
