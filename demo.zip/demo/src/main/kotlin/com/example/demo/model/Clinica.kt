package com.example.demo.model

import javax.persistence.*
@Entity
@Table(name = "clinica")//,catalog="dbo" Si fueran catalogos
data class Clinica( val nombreClinica: String = "",val telefono:Int =0,val codigoDireccion: Int,
                    val codigoEmpleado: Int = 0){
    @Id
    var codigoClinica: Long = 0

}
