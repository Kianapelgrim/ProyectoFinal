package com.example.demo.web

import com.example.demo.business.IPersonaBussiness
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Persona
import com.example.demo.utils.Constants
import com.example.demo.utils.RestApiError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.lang.Exception

@RestController
@RequestMapping(Constants.URL_BASE_PERSONAS)
class PersonaRestController {
    @Autowired
    val personaBusiness:IPersonaBussiness?= null
    @GetMapping("")
    fun list():ResponseEntity<List<Persona>>{
        return try {
            ResponseEntity(personaBusiness!!.getPersonas(),HttpStatus.OK)
        }catch (e: Exception){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @GetMapping("/id/{id}")
    fun loadById(@PathVariable("id")idPersona: Long):ResponseEntity<Persona>{
        return try {
            ResponseEntity(personaBusiness!!.getPersonaById(idPersona),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
        ResponseEntity(HttpStatus.NOT_FOUND)
    }
    }
    @GetMapping ("/nombre/{nombre}")
    fun loadByNombre(@PathVariable("nombre")nombrePersona: String):ResponseEntity<Persona>{
        return try {
            ResponseEntity(personaBusiness!!.getPersonaByNombre(nombrePersona),HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        } catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @PostMapping("/addPersona")
    fun insert(@RequestBody persona: Persona):ResponseEntity<Any>{
        return try {
            personaBusiness!!.savePersona(persona)
            val responseHeader = HttpHeaders()
            responseHeader.set("location",Constants.URL_BASE_PERSONAS+"/"+persona.id)
            ResponseEntity(persona,responseHeader, HttpStatus.CREATED)
        }catch (e: BusinessException){
            val apiError = RestApiError(HttpStatus.INTERNAL_SERVER_ERROR,"Informacion Enviada no es Valida",e.message.toString())
            ResponseEntity(apiError,HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PostMapping("/addPersonas")
    fun insert(@RequestBody persona: List<Persona>):ResponseEntity<Any>{
        return try {
            ResponseEntity(personaBusiness!!.savePersonas(persona),HttpStatus.CREATED)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }
    }
    @PutMapping
    fun update(@RequestBody persona: Persona):ResponseEntity<Any>{
        return try {
            personaBusiness!!.updatePersona(persona)
            ResponseEntity(persona,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
    @DeleteMapping("/delete/{id}")
    fun delete(@PathVariable ("id")idPersona: Long):ResponseEntity<Any>{
        return try {
            personaBusiness!!.removePersona(idPersona)
            ResponseEntity(idPersona,HttpStatus.OK)
        }catch (e: BusinessException){
            ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR)
        }catch (e: NotFoundException){
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }
}