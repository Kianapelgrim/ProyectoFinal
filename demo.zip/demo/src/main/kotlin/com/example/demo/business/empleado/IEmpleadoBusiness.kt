package com.example.demo.business.direccion
import com.example.demo.model.Empleado


interface IEmpleadoBusiness {
    fun getEmpleados():List<Empleado>
    fun getEmpleadoById(idEmpleado: Long): Empleado
    fun saveEmpleado (empleado: Empleado): Empleado
    fun saveEmpleados(empleado: List<Empleado>): List<Empleado>
    fun removeEmpleado(idEmpleado: Long)
    fun getByNombreEmpleado(nombreEmpleado: String): Empleado
    fun updateEmpleado(empleado: Empleado): Empleado
    fun getByEmail(emailEmpleado:String):Empleado

}