package com.example.demo.business.citaDetalleProducto
import com.example.demo.model.FacturaDetalleProducto

interface IFacturaDetalleProductoBusiness {
    fun getFacturaDetalleProductos():List<FacturaDetalleProducto>
    fun getFacturaDetalleProductoById(idFacturaDetalleProducto: Long): FacturaDetalleProducto
    fun saveFacturaDetalleProducto (facturaDetalleProducto: FacturaDetalleProducto): FacturaDetalleProducto
    fun saveFacturaDetalleProductos(facturaDetalleProducto: List<FacturaDetalleProducto>): List<FacturaDetalleProducto>
    fun removeFacturaDetalleProducto(idFacturaDetalleProducto: Long)
    fun getByCodigoProducto(codigoProducto: Int): FacturaDetalleProducto
    fun updateFacturaDetalleProducto(facturaDetalleProducto: FacturaDetalleProducto): FacturaDetalleProducto

}