package com.example.demo.business
import com.example.demo.dao.PersonaRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Persona
import com.example.demo.model.Receta
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.time.LocalDate
import java.util.*
import kotlin.jvm.Throws

@Service
class PersonaBusiness:IPersonaBussiness {
@Autowired
val personaRepository:PersonaRepository?=null
    @Throws(BusinessException::class)
    override fun getPersonas(): List<Persona> {
        try{
           return personaRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getPersonaById(idPersona: Long): Persona {
        val opt:Optional<Persona>
        try{
             opt = personaRepository!!.findById(idPersona)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la persona $idPersona")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun savePersona(persona: Persona): Persona {
        try{
            if (validaciones(persona)!=null){
                throw BusinessException(validaciones(persona))
            }
            return  personaRepository!!.save(persona)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun savePersonas(personas: List<Persona>): List<Persona> {
        try{
            return personaRepository!!.saveAll(personas)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removePersona(idPersona: Long) {
        val opt:Optional<Persona>
        try{
            opt = personaRepository!!.findById(idPersona)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la persona $idPersona")
        }else{
            try{
                personaRepository!!.deleteById(idPersona)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getPersonaByNombre(nombrePersona: String): Persona {
        val opt:Optional<Persona>
        try{
            opt = personaRepository!!.findByNombre(nombrePersona)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la persona $nombrePersona")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updatePersona(persona: Persona): Persona {
        val opt:Optional<Persona>
        try{
            if (validaciones(persona)!=null){
                throw BusinessException(validaciones(persona))
            }
            opt = personaRepository!!.findById(persona.id)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la persona ${persona.id}")
        }else{
            try{
                return  personaRepository!!.save(persona)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }
    fun validaciones(persona: Persona):String?{
        var message:String? =null
        var now: LocalDate = LocalDate.now()
        if (persona.id==null){
            message= "Ingrese un código"
        }
        if (persona.apellido==null){
            message= "Ingrese un apellido"
        }
        if (persona.nombre==null){
            message= "Ingrese un nombre"
        }
        if (persona.dni==null){
            message= "Ingrese un dni"
        }
        if (persona.fechaNacimiento==null){
            message= "Ingrese una fecha de nacimiento"
        }
        if (persona.fechaNacimiento!!.isAfter(now)){
            message = "Ingrese una fecha de nacimiento válida"
        }
        if (persona.dni<999999999999||persona.dni>10000000000000){
            message = "Ingrese un dni válido"
        }

        return message
    }
}
