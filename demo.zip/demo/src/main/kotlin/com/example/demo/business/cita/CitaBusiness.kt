package com.example.demo.business.cita
import com.example.demo.dao.CitaRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Cita
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class CitaBusiness: ICitaBusiness {
    @Autowired
    val citaRepository:CitaRepository?=null
    @Throws(BusinessException::class)
    override fun getCitas(): List<Cita> {
        try{
            return citaRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getCitaById(idCita: Long): Cita {
        val opt:Optional<Cita>
        try{
            opt = citaRepository!!.findById(idCita)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la cita  $idCita")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveCita(cita: Cita): Cita{
        try{
            if (cita.estado.length<5)
                throw BusinessException("Ingrese un estado de mas de 5 caracteres")
            return  citaRepository!!.save(cita)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveCitas(cita: List<Cita>): List<Cita> {
        try{
            return citaRepository!!.saveAll(cita)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeCita(idCita: Long) {
        val opt:Optional<Cita>
        try{
            opt = citaRepository!!.findById(idCita)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la cita $idCita")
        }else{
            try{
                citaRepository!!.deleteById(idCita)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getByEstado(estado: String): Cita {
        val opt:Optional<Cita>
        try{
            opt = citaRepository!!.findByEstado(estado)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la cita $estado")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateCita(cita: Cita): Cita {
        val opt:Optional<Cita>
        try{
            opt = citaRepository!!.findById(cita.codigoCita)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la cita ${cita.codigoCita}")
        }else{
            try{
                return  citaRepository!!.save(cita)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}