package com.example.demo.business.cita
import com.example.demo.model.Cita
interface ICitaBusiness {
    fun getCitas():List<Cita>
    fun getCitaById(idCita: Long): Cita
    fun saveCita (cita: Cita): Cita
    fun saveCitas(cita: List<Cita>): List<Cita>
    fun removeCita(idCita: Long)
    fun getByEstado(estado: String): Cita
    fun updateCita(cita: Cita): Cita

}