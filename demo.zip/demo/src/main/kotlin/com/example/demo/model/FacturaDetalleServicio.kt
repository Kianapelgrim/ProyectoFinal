package com.example.demo.model
import javax.persistence.*

@Entity
@Table(name = "FacturaDetalleServicio")
data class FacturaDetalleServicio(val codigoServicio: Int = 0){
    @Id
    var codigoFactura: Long = 0
}
