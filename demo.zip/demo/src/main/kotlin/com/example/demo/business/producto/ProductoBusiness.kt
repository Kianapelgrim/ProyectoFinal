package com.example.demo.business.producto
import com.example.demo.dao.ProductoRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Producto
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class ProductoBusiness: IProductoBussiness {
    @Autowired
val productoRepository: ProductoRepository?=null
    @Throws(BusinessException::class)
    override fun getProductos(): List<Producto> {
        try{
            return productoRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getProductoById(idProducto: Long): Producto {
        val opt:Optional<Producto>
        try{
            opt = productoRepository!!.findById(idProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Producto $idProducto")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveProducto(producto: Producto): Producto {
        try{
            if (validaciones(producto)!=null){
            throw BusinessException(validaciones(producto))
        }
            if (producto.nombreProducto.length<5)
                throw BusinessException("Ingrese en el nombre del producto mas de 5 caracteres")
            return  productoRepository!!.save(producto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveProductos(productos: List<Producto>): List<Producto> {
        try{
            return productoRepository!!.saveAll(productos)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeProducto(idProducto: Long) {
        val opt:Optional<Producto>
        try{
            opt = productoRepository!!.findById(idProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Producto $idProducto")
        }else{
            try{
                productoRepository!!.deleteById(idProducto)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getProductoByNombre(nombreProducto: String): Producto {
        val opt:Optional<Producto>
        try{
            opt = productoRepository!!.findByNombreProducto(nombreProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Producto $nombreProducto")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateProducto(producto: Producto): Producto {
        val opt:Optional<Producto>
        try{
            if (validaciones(producto)!=null){
                throw BusinessException(validaciones(producto))
            }
            opt = productoRepository!!.findById(producto.codigoProducto)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro el Producto ${producto.codigoProducto}")
        }else{
            try{
                return  productoRepository!!.save(producto)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }
fun validaciones(producto: Producto):String?{
    var message: String?= null
    if (producto.codigoProducto==null){
        message= "Ingrese un código"
    }
    if (producto.nombreProducto==null){
        message= "Ingrese un nombre de producto"
    }
    if (producto.precio==null){
        message= "Ingrese un precio de producto"
    }
    if (producto.stockActual==null){
        message= "Ingrese un stock actual de producto"
    }
    if (producto.stockMaximo==null){
        message= "Ingrese un stock máximo de producto"
    }
    if (producto.stockMinimo==null){
        message= "Ingrese un stock mínimo de producto"
    }
    if (producto.stockActual<0)
    {message= "ingrese un stock actual valido"}
    if (producto.stockMinimo<0)
    {message= "ingrese un stock minimo valido"}
    if (producto.stockMaximo<0)
    {message= "ingrese un stock maximo valido"}
    if (producto.precio<0)
    {message= "ingrese un precio valido"}
    if (producto.codigoProducto<0){
        message= "Ingrese un código válido"
    }


    return message
}
}