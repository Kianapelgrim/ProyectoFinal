package com.example.demo.business.direccion
import com.example.demo.dao.DireccionRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.Direccion
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class DireccionBusiness: IDireccionBusiness {
    @Autowired
    val direccionRepository:DireccionRepository?=null
    @Throws(BusinessException::class)
    override fun getDireccions(): List<Direccion> {
        try{
            return direccionRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getDireccionById(idDireccion: Long): Direccion {
        val opt:Optional<Direccion>
        try{
            opt = direccionRepository!!.findById(idDireccion)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la direccion $idDireccion")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveDireccion(direccion: Direccion): Direccion {
        try{
            if (direccion.ciudad.length<5)
                throw BusinessException("Ingrese en la ciudad mas de 5 caracteres")
            return  direccionRepository!!.save(direccion)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveDireccions(direccions: List<Direccion>): List<Direccion> {
        try{
            return direccionRepository!!.saveAll(direccions)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeDireccion(idDireccion: Long) {
        val opt:Optional<Direccion>
        try{
            opt = direccionRepository!!.findById(idDireccion)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la persona $idDireccion")
        }else{
            try{
                direccionRepository!!.deleteById(idDireccion)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getDireccionByCiudad(ciudad: String): Direccion {
        val opt:Optional<Direccion>
        try{
            opt = direccionRepository!!.findByCiudad(ciudad)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la direccion $ciudad")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateDireccion(direccion: Direccion): Direccion {
        val opt:Optional<Direccion>
        try{
            opt = direccionRepository!!.findById(direccion.codigoDireccion)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la direccion ${direccion.codigoDireccion}")
        }else{
            try{
                return  direccionRepository!!.save(direccion)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}