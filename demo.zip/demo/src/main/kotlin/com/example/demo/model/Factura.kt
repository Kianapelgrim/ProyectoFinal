package com.example.demo.model
import java.time.LocalDate
import java.time.LocalTime
import javax.persistence.*

@Entity
@Table(name = "factura")
data class Factura(val codigoEmpleado: Int = 0, val codigoPaciente: Int = 0,
                val codigoCita: Int = 0, val cai: String = "",
                val fechaDeRealizacion:LocalDate?=null,val horaDeRealizacion: LocalTime?=null,
                val fechaDeVencimiento:LocalDate?=null,val precioTotal:Float = 0.0f){
    @Id
    var codigoFactura: Long = 0

}
