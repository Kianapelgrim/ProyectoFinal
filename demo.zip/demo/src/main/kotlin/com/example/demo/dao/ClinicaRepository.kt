package com.example.demo.dao
import com.example.demo.model.Clinica
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.*
@Repository
interface ClinicaRepository:JpaRepository<Clinica,Long> {
    fun findByNombreClinica(nombreClinica:String):Optional<Clinica>
}