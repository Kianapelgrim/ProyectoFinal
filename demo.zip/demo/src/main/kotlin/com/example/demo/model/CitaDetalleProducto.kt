package com.example.demo.model

import javax.persistence.*

@Entity
@Table(name = "citaDetalleProducto")
data class CitaDetalleProducto(val codigoServicio: Int = 0){
    @Id
    var codigoCita: Long = 0
}
