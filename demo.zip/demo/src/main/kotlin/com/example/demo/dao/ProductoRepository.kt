package com.example.demo.dao
import com.example.demo.model.Producto
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.*
@Repository
interface ProductoRepository:JpaRepository<Producto,Long> {
    fun findByNombreProducto(nombreProducto:String):Optional<Producto>
}