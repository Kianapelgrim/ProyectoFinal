import com.example.demo.business.citaDetalleProducto.IFacturaDetalleServicioBusiness
import com.example.demo.dao.FacturaDetalleServicioRepository
import com.example.demo.exceptions.BusinessException
import com.example.demo.exceptions.NotFoundException
import com.example.demo.model.FacturaDetalleServicio
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class FacturaDetalleServicioBusiness: IFacturaDetalleServicioBusiness {
    @Autowired
    val facturaDetalleServicioRepository: FacturaDetalleServicioRepository?=null
    @Throws(BusinessException::class)
    override fun getFacturaDetalleServicios(): List<FacturaDetalleServicio> {
        try{
            return facturaDetalleServicioRepository!!.findAll()

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getFacturaDetalleServicioById(idFacturaDetalleServicio: Long): FacturaDetalleServicio {
        val opt:Optional<FacturaDetalleServicio>
        try{
            opt = facturaDetalleServicioRepository!!.findById(idFacturaDetalleServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleServicio $idFacturaDetalleServicio")
        }
        return opt.get()

    }
    @Throws(BusinessException::class)
    override fun saveFacturaDetalleServicio(facturaDetalleServicio: FacturaDetalleServicio): FacturaDetalleServicio {
        try{
            if (facturaDetalleServicio.codigoServicio==0)
                throw BusinessException("Ingrese un codigo de servicio distinto a 0")
            return  facturaDetalleServicioRepository!!.save(facturaDetalleServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }
    @Throws(BusinessException::class)
    override fun saveFacturaDetalleServicios(facturaDetalleServicio: List<FacturaDetalleServicio>): List<FacturaDetalleServicio> {
        try{
            return facturaDetalleServicioRepository!!.saveAll(facturaDetalleServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
    }

    @Throws(BusinessException::class, NotFoundException::class)
    override fun removeFacturaDetalleServicio(idFacturaDetalleServicio: Long) {
        val opt:Optional<FacturaDetalleServicio>
        try{
            opt = facturaDetalleServicioRepository!!.findById(idFacturaDetalleServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleServicio $idFacturaDetalleServicio")
        }else{
            try{
                facturaDetalleServicioRepository!!.deleteById(idFacturaDetalleServicio)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }

    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun getByCodigoServicio(codigoServicio: Int): FacturaDetalleServicio {
        val opt:Optional<FacturaDetalleServicio>
        try{
            opt = facturaDetalleServicioRepository!!.findBycodigoServicio(codigoServicio)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleServicio $codigoServicio")
        }
        return opt.get()
    }
    @Throws(BusinessException::class, NotFoundException::class)
    override fun updateFacturaDetalleServicio(facturaDetalleServicio: FacturaDetalleServicio): FacturaDetalleServicio {
        val opt:Optional<FacturaDetalleServicio>
        try{
            opt = facturaDetalleServicioRepository!!.findById(facturaDetalleServicio.codigoFactura)

        }catch (e:Exception){
            throw BusinessException(e.message);
        }
        if (!opt.isPresent){
            throw NotFoundException("No se encontro la FacturaDetalleServicio ${facturaDetalleServicio.codigoFactura}")
        }else{
            try{
                return  facturaDetalleServicioRepository!!.save(facturaDetalleServicio)
            }catch (e:Exception){
                throw BusinessException(e.message);
            }
        }
        return opt.get()
    }

}