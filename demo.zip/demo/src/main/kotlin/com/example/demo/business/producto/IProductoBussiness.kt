package com.example.demo.business.producto
import com.example.demo.model.Producto
interface IProductoBussiness {
    fun getProductos():List<Producto>
    fun getProductoById(idProducto:Long): Producto
    fun saveProducto (producto: Producto): Producto
    fun saveProductos(producto: List<Producto>): List<Producto>
    fun removeProducto(idProducto: Long)
    fun getProductoByNombre(nombreProducto: String): Producto
    fun updateProducto(producto: Producto): Producto
}