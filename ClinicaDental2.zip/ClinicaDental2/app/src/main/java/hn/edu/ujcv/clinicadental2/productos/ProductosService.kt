package hn.edu.ujcv.clinicadental2.productos
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface ProductosService {
    @GET("productos")
    fun listProductos(): Call<List<ProductosDataCollectionItem>>
    @GET("productos/id/{id}")
    fun getProductoById(@Path("id") id: Long): Call<ProductosDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("productos/addProducto")
    fun addProducto(@Body ProductosData: ProductosDataCollectionItem): Call<ProductosDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("productos")
    fun updateProducto(@Body ProductosData: ProductosDataCollectionItem): Call<ProductosDataCollectionItem>
    @DELETE("productos/delete/{id}")
    fun deleteProducto(@Path("id") id: Long): Call<ResponseBody>
}