package hn.edu.ujcv.clinicadental2

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.MediaController
import android.widget.Toast
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosDataCollectionItem
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosService
import hn.edu.ujcv.clinicadental2.empleados.RestEngine
import hn.edu.ujcv.clinicadental2.user.userActivity
import kotlinx.android.synthetic.main.activity_empleados.*
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val mediaController = MediaController(this)
        mediaController.setAnchorView(videoView)
        val offlineUri = Uri.parse("android.resource://$packageName/${R.raw.login2}")
        videoView.setVideoURI(offlineUri)
        videoView.requestFocus()
        videoView.start()
        var intent = Intent(this, userActivity::class.java)
        btnLogin.setOnClickListener { startActivity(intent) }
    }

}