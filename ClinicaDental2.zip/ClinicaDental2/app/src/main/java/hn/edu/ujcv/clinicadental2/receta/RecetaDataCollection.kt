package hn.edu.ujcv.clinicadental2.receta

class RecetaDataCollection : ArrayList<RecetaDataCollection>()

data class RecetaDataCollectionItem(
    val codigoReceta: Long,
    val medicamento: String,
    val indicaciones: String,
    val codigoCita: Int,

)
