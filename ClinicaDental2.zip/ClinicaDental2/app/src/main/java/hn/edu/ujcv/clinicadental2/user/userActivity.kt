package hn.edu.ujcv.clinicadental2.user

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import hn.edu.ujcv.clinicadental2.MainActivity
import hn.edu.ujcv.clinicadental2.R
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosDataCollectionItem
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosService
import hn.edu.ujcv.clinicadental2.empleados.RestEngine
import kotlinx.android.synthetic.main.activity_empleados.*
import kotlinx.android.synthetic.main.activity_user.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class userActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)

        val intent  = Intent(this, MainActivity::class.java)

        btnEntrar.setOnClickListener{startActivity(intent)}
    }
    private fun callServiceGetEmpleadoByCorreo() {
        val empleadoService: EmpleadosService = RestEngine.buildService().create(EmpleadosService::class.java)
        var result: Call<EmpleadosDataCollectionItem> = empleadoService.getEmpleadoByCorreo(txtUserIntro.text.toString())

        result.enqueue(object : Callback<EmpleadosDataCollectionItem> {
            override fun onFailure(call: Call<EmpleadosDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@userActivity,"Error1", Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<EmpleadosDataCollectionItem>,
                response: Response<EmpleadosDataCollectionItem>
            ) {
                if (response.code() == 404) {
                    Toast.makeText(this@userActivity,"Este Empleado no existe", Toast.LENGTH_LONG).show()
                } else {
                 if (txtPasswordIntro.text.toString()==response.body()!!.contraseña){
                     Toast.makeText(this@userActivity,"OK"+response.body()!!.nombre, Toast.LENGTH_LONG).show()
                    startActivity(intent)
                 }else{Toast.makeText(this@userActivity,"Nada"+response.body()!!.nombre, Toast.LENGTH_LONG).show()
                 }


                }

            }
        })
    }
}