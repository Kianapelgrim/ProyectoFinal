package hn.edu.ujcv.clinicadental2.empleados

class EmpleadosDataCollection : ArrayList<EmpleadosDataCollection>()

data class EmpleadosDataCollectionItem(
    val codigoEmpleado: Long?,
    val nombre: String,
    val apellido: String,
    val telefono: Long,
    val identificacion: Long,
    val puesto: String,
    val fechaNacimiento: String,
    val correo: String,
    val fechaInicio: String,
    val contraseña: String,
    val codigoDireccion: Int
)
