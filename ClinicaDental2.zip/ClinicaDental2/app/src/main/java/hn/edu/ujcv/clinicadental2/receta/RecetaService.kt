package hn.edu.ujcv.clinicadental2.receta
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface RecetaService {
    @GET("recetas")
    fun listRecetas(): Call<List<RecetaDataCollectionItem>>
    @GET("recetas/id/{id}")
    fun getRecetaById(@Path("id") id: Long): Call<RecetaDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("recetas/addReceta")
    fun addReceta(@Body RecetasData: RecetaDataCollectionItem): Call<RecetaDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("recetas")
    fun updateReceta(@Body RecetasData: RecetaDataCollectionItem): Call<RecetaDataCollectionItem>
    @DELETE("recetas/delete/{id}")
    fun deleteReceta(@Path("id") id: Long): Call<ResponseBody>
}