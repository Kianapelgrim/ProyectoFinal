package hn.edu.ujcv.clinicadental2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import hn.edu.ujcv.clinicadental2.cita.CitasActivity
import hn.edu.ujcv.clinicadental2.clinica.ClinicasActivity
import hn.edu.ujcv.clinicadental2.direccion.DireccionsActivity
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosActivity
import hn.edu.ujcv.clinicadental2.factura.FacturasActivity
import hn.edu.ujcv.clinicadental2.paciente.PacientesActivity
import hn.edu.ujcv.clinicadental2.productos.ProductosActivity
import hn.edu.ujcv.clinicadental2.receta.RecetasActivity


class RecycleAdapter: RecyclerView.Adapter<RecycleAdapter.ViewHolder>() {
    private val title  = arrayOf("Empleados","Pacientes","Citas","Productos","Facturas","Recetas","Direccion","Clinica")
    private val detail = arrayOf("Doctores o Cajeros", "Crear nuevo paciente", "Crear nueva cita",
        "Crear nuevo Producto", "Crear nueva Factura", "Crear nueva Receta", "Crear nueva Direccion", "Crear nueva Clinica")
    private val iconos = intArrayOf(R.drawable.empleado,
        R.drawable.paciente,R.drawable.cita,R.drawable.producto,R.drawable.facturas,R.drawable.recetas,R.drawable.direccion,R.drawable.clinica)

    override fun onCreateViewHolder(ViewGroup: ViewGroup, viewType: Int):ViewHolder {
        val v = LayoutInflater.from(ViewGroup.context)
            .inflate(R.layout.cardviewmenu,ViewGroup,false)
        return ViewHolder(v)
    }

    @Override
    override fun onViewRecycled(holder: ViewHolder) {

    }
    inner class ViewHolder(item_view: View) : RecyclerView.ViewHolder(item_view){
        var itemImagen : ImageView
        var itemTitle: TextView
        var itemDetail: TextView
        init {
            itemImagen  = item_view.findViewById(R.id.item_Imagen)
            itemTitle  = item_view.findViewById(R.id.item_titulo)
            itemDetail  = item_view.findViewById(R.id.item_info)
            //SetOnClickListener{}
            item_view.setOnClickListener { v: View ->
                var position: Int = getAdapterPosition()
                val intent= Intent(item_view.context,EmpleadosActivity::class.java)
                if(position==0){
                    item_view.context.startActivity(intent)
                }
                val intentPacientes= Intent(item_view.context,PacientesActivity::class.java)
                if(position==1){
                    item_view.context.startActivity(intentPacientes)
                }
                val intentCitas= Intent(item_view.context,CitasActivity::class.java)

                if(position==2){
                    item_view.context.startActivity(intentCitas)
                }
                val intentProductos= Intent(item_view.context, ProductosActivity::class.java)

                if(position==3){
                    item_view.context.startActivity(intentProductos)
                }
                val intentFacturas= Intent(item_view.context, FacturasActivity::class.java)

                if(position==4){
                    item_view.context.startActivity(intentFacturas)
                }
                val intentRecetas= Intent(item_view.context, RecetasActivity::class.java)

                if(position==5){
                    item_view.context.startActivity(intentRecetas)
                }
                val intentDireccion= Intent(item_view.context, DireccionsActivity::class.java)

                if(position==6){
                    item_view.context.startActivity(intentDireccion)
                }
                val intentClinica= Intent(item_view.context, ClinicasActivity::class.java)

                if(position==7){
                    item_view.context.startActivity(intentClinica)
                }

                //Snackbar.make(v, "  ",
                    //Snackbar.LENGTH_LONG).setAction("Action", null).show()

            }
        }
    }

    override fun onBindViewHolder(ViewHolder: ViewHolder, position: Int) {
        ViewHolder.itemTitle.text=title[position]
        ViewHolder.itemDetail.text=detail[position]
        ViewHolder.itemImagen.setImageResource(iconos[position])


    }

    override fun getItemCount(): Int {
        return title.size
    }

}