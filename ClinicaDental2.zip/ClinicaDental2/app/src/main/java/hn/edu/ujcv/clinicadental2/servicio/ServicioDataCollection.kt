package hn.edu.ujcv.clinicadental2.servicio

class ServicioDataCollection : ArrayList<ServicioDataCollection>()

data class ServicioDataCollectionItem(
    val codigoServicio: Long,
    val nombreServicio: String,
    val descripcion: String,
)
