package hn.edu.ujcv.clinicadental2.factura

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hn.edu.ujcv.clinicadental2.MainActivity
import hn.edu.ujcv.clinicadental2.R
import kotlinx.android.synthetic.main.activity_facturas.*

class FacturasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_facturas)
        btnAtrasF.setOnClickListener { val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)}
}
}