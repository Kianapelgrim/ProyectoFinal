package hn.edu.ujcv.clinicadental2.paciente
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface PacienteService {
    @GET("pacientes")
    fun listPacientes(): Call<List<PacienteDataCollectionItem>>
    @GET("pacientes/id/{id}")
    fun getPacienteById(@Path("id") id: Long): Call<PacienteDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("pacientes/addPaciente")
    fun addPaciente(@Body PacienteData: PacienteDataCollectionItem): Call<PacienteDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("pacientes")
    fun updatePaciente(@Body PacienteData: PacienteDataCollectionItem): Call<PacienteDataCollectionItem>
    @DELETE("pacientes/delete/{id}")
    fun deletePaciente(@Path("id") id: Long): Call<ResponseBody>
}