package hn.edu.ujcv.clinicadental2.citaDetalleProducto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hn.edu.ujcv.clinicadental2.R
import hn.edu.ujcv.clinicadental2.cita.CitasDataCollectionItem
import hn.edu.ujcv.clinicadental2.cita.CitasService
import hn.edu.ujcv.clinicadental2.empleados.RestEngine
import kotlinx.android.synthetic.main.activity_citas.*
import retrofit2.Call

class CitaDetalleProductoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cita_detalle_producto)
    }
    private fun callServiceGetCitaDetalle() {
        val citaDetalleProductoService: CitaDetalleProductosService = RestEngine.buildService().create(CitaDetalleProductosService::class.java)

    }
}