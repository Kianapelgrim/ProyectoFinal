package hn.edu.ujcv.clinicadental2.cita

import java.time.LocalTime
import java.util.*
import kotlin.collections.ArrayList

class CitasDataCollection : ArrayList<CitasDataCollection>()

data class CitasDataCollectionItem(
    val codigoCita: Long,
    val estado: String,
    val fecha: String,
    val hora: String,
    val codigoClinica: Long,
    val codigoPaciente: Int,
    val codigoEmpleado: Int,
    val fechaDeRegistro: String
    )
