package hn.edu.ujcv.clinicadental2.empleados
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface EmpleadosService {
    @GET("empleados")
    fun listEmpleados(): Call<List<EmpleadosDataCollectionItem>>
    @GET("empleados/id/{id}")
    fun getEmpleadoById(@Path("id") id: Long): Call<EmpleadosDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("empleados/addEmpleado")
    fun addEmpleado(@Body EmpleadoData: EmpleadosDataCollectionItem): Call<EmpleadosDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("empleados")
    fun updateEmpleado(@Body EmpleadosData: EmpleadosDataCollectionItem): Call<EmpleadosDataCollectionItem>
    @DELETE("empleados/delete/{id}")
    fun deleteEmpleado(@Path("id") id: Long): Call<ResponseBody>
    @GET("empleados/emailEmpleado/{emailEmpleado}")
    fun getEmpleadoByCorreo(@Path("emailEmpleado") correo:String ): Call<EmpleadosDataCollectionItem>

}