package hn.edu.ujcv.clinicadental2.factura
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface FacturasService {
    @GET("facturas")
    fun listFacturas(): Call<List<FacturaDataCollecionItem>>
    @GET("facturas/id/{id}")
    fun getFacturaById(@Path("id") id: Long): Call<FacturaDataCollecionItem>
    @Headers("Content-Type: application/json")
    @POST("facturas/addFactura")
    fun addFactura(@Body FacturaData: FacturaDataCollecionItem): Call<FacturaDataCollecionItem>
    @Headers("Content-Type: application/json")
    @PUT("facturas")
    fun updateFactura(@Body FacturaData: FacturaDataCollecionItem): Call<FacturaDataCollecionItem>
    @DELETE("facturas/delete/{id}")
    fun deleteFactura(@Path("id") id: Long): Call<ResponseBody>
}