package hn.edu.ujcv.clinicadental2.empleados

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson
import hn.edu.ujcv.clinicadental2.MainActivity
import hn.edu.ujcv.clinicadental2.R
import hn.edu.ujcv.clinicadental2.entities.RestApiError
import kotlinx.android.synthetic.main.activity_empleados.*
import kotlinx.android.synthetic.main.activity_user.*
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EmpleadosActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_empleados)
    btnBuscarIdEmpleado.setOnClickListener { v-> callServiceGetEmpleado() }
    btnGuardarEmpleado.setOnClickListener { callServicePostEmpleado() }
    btnEliminarEmpleado.setOnClickListener { callServiceDeleteEmpleado() }
    btnActualizarEmpleado.setOnClickListener { callServicePutEmpleado() }
    btnAtras.setOnClickListener { val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)}
}

            private fun callServiceGetEmpleado() {
                val empleadoService:EmpleadosService = RestEngine.buildService().create(EmpleadosService::class.java)
                var result: Call<EmpleadosDataCollectionItem> = empleadoService.getEmpleadoById(txtCodigoEmpleado.text.toString().toLong())

                result.enqueue(object : Callback<EmpleadosDataCollectionItem> {
                    override fun onFailure(call: Call<EmpleadosDataCollectionItem>, t: Throwable) {
                        Toast.makeText(this@EmpleadosActivity,"Error", Toast.LENGTH_LONG).show()
                    }

                    override fun onResponse(
                        call: Call<EmpleadosDataCollectionItem>,
                        response: Response<EmpleadosDataCollectionItem>
                    ) {
                        if (response.code() == 404) {
                            txtNombreEmpleado.setText(" ")
                            txtApellidoEmpleado.setText(" ")
                            txtTelefonoEmpleado.setText(" ")
                            txtFechaNacimientoEmpleado.setText(" ")
                            txtCorreoEmpleado.setText(" ")
                            txtIdentificacionEmpleado.setText(" ")
                            txtContrasenia.setText(" ")
                            Toast.makeText(this@EmpleadosActivity,"Este Empleado no existe",Toast.LENGTH_LONG).show()
                        } else {
                            txtNombreEmpleado.setText(response.body()!!.nombre)
                            txtApellidoEmpleado.setText(response.body()!!.apellido)
                            txtTelefonoEmpleado.setText(response.body()!!.telefono.toString())
                            txtFechaNacimientoEmpleado.setText(response.body()!!.fechaNacimiento)
                            txtCorreoEmpleado.setText(response.body()!!.correo)
                            txtIdentificacionEmpleado.setText(response.body()!!.identificacion.toString())
                            txtContrasenia.setText(response.body()!!.contraseña)

                            Toast.makeText(this@EmpleadosActivity,"OK"+response.body()!!.nombre, Toast.LENGTH_LONG).show()
                        }
                    }
                })
            }


    private fun callServicePostEmpleado() {
        val fecha = txtFechaNacimientoEmpleado.text
        val EmpleadoInfo = EmpleadosDataCollectionItem(  codigoEmpleado = txtCodigoEmpleado.text.toString().toLong(),
            nombre = txtNombreEmpleado.text.toString(),
            apellido = txtApellidoEmpleado.text.toString(),
            telefono = txtTelefonoEmpleado.text.toString().toLong(),
            identificacion = txtIdentificacionEmpleado.text.toString().toLong(),
            puesto = "Medico",
            fechaNacimiento = txtFechaNacimientoEmpleado.text.toString(),
            correo = txtCorreoEmpleado.text.toString(),
            fechaInicio = "2021-02-03",
            contraseña = txtContrasenia.text.toString(),
            codigoDireccion = 12
        )

        addEmpleado(EmpleadoInfo) {
            if (it?.codigoEmpleado != null) {
                Toast.makeText(this@EmpleadosActivity,"OK"+it?.codigoEmpleado,Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@EmpleadosActivity,"Error",Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun callServiceDeleteEmpleado() {
        val empleadoService:EmpleadosService = RestEngine.buildService().create(EmpleadosService::class.java)
        var result: Call<ResponseBody> = empleadoService.deleteEmpleado(txtCodigoEmpleado.text.toString().toLong())

        result.enqueue(object :  Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(this@EmpleadosActivity,"Error",Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<ResponseBody>,
                response: Response<ResponseBody>
            ) {
                if (response.isSuccessful) {
                    Toast.makeText(this@EmpleadosActivity,"DELETE",Toast.LENGTH_LONG).show()
                }
                else if (response.code() == 401){
                    Toast.makeText(this@EmpleadosActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@EmpleadosActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }
        })
    }
    private fun callServicePutEmpleado() {
        val fecha = txtFechaNacimientoEmpleado.text
        val empleadoInfo = EmpleadosDataCollectionItem(  codigoEmpleado = txtCodigoEmpleado.text.toString().toLong(),
            nombre = txtNombreEmpleado.text.toString(),
            apellido = txtApellidoEmpleado.text.toString(),
            telefono = txtTelefonoEmpleado.text.toString().toLong(),
            identificacion = txtIdentificacionEmpleado.text.toString().toLong(),
            puesto = "Medico",
            fechaNacimiento = txtFechaNacimientoEmpleado.text.toString(),
            correo = txtCorreoEmpleado.text.toString(),
            fechaInicio = "2021-02-03",
            contraseña = txtContrasenia.text.toString(),
            codigoDireccion = 12
        )

        val retrofit = RestEngine.buildService().create(EmpleadosService::class.java)
        var result: Call<EmpleadosDataCollectionItem> = retrofit.updateEmpleado(empleadoInfo)

        result.enqueue(object : Callback<EmpleadosDataCollectionItem> {
            override fun onFailure(call: Call<EmpleadosDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@EmpleadosActivity,"Error",Toast.LENGTH_LONG).show()
            }

            override fun onResponse(call: Call<EmpleadosDataCollectionItem>,
                                    response: Response<EmpleadosDataCollectionItem>) {
                if (response.isSuccessful) {
                    val updateEmpleado = response.body()!!
                    Toast.makeText(this@EmpleadosActivity,"OK"+response.body()!!.nombre,Toast.LENGTH_LONG).show()
                }
                else if (response.code() == 401){
                    Toast.makeText(this@EmpleadosActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@EmpleadosActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }

        })
    }
    private fun callServiceGetEmpleadoByCorreo() {
        val empleadoService: EmpleadosService = RestEngine.buildService().create(EmpleadosService::class.java)
        var result: Call<EmpleadosDataCollectionItem> = empleadoService.getEmpleadoByCorreo(txtUserIntro.text.toString())

        result.enqueue(object : Callback<EmpleadosDataCollectionItem> {
            override fun onFailure(call: Call<EmpleadosDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@EmpleadosActivity,"Error1", Toast.LENGTH_LONG).show()
            }

            override fun onResponse( call: Call<EmpleadosDataCollectionItem>,
                                     response: Response<EmpleadosDataCollectionItem>
            ) {
                if (response.code() == 404) {
                    txtNombreEmpleado.setText(" ")
                    txtApellidoEmpleado.setText(" ")
                    txtTelefonoEmpleado.setText(" ")
                    txtFechaNacimientoEmpleado.setText(" ")
                    txtCorreoEmpleado.setText(" ")
                    txtIdentificacionEmpleado.setText(" ")
                    txtContrasenia.setText(" ")
                    Toast.makeText(this@EmpleadosActivity,"Este Empleado no existe",Toast.LENGTH_LONG).show()
                } else {
                    txtNombreEmpleado.setText(response.body()!!.nombre)
                    txtApellidoEmpleado.setText(response.body()!!.apellido)
                    txtTelefonoEmpleado.setText(response.body()!!.telefono.toString())
                    txtFechaNacimientoEmpleado.setText(response.body()!!.fechaNacimiento)
                    //txtCorreoEmpleado.setText(response.body()!!.correo)
                    txtIdentificacionEmpleado.setText(response.body()!!.identificacion.toString())
                    txtContrasenia.setText(response.body()!!.contraseña)

                    Toast.makeText(this@EmpleadosActivity,"OK"+response.body()!!.nombre, Toast.LENGTH_LONG).show()
                }
            }
        })
    }
    fun addEmpleado(empleadoData: EmpleadosDataCollectionItem, onResult: (EmpleadosDataCollectionItem?) -> Unit){
        val retrofit = RestEngine.buildService().create(EmpleadosService::class.java)
        var result: Call<EmpleadosDataCollectionItem> = retrofit.addEmpleado(empleadoData)

        result.enqueue(object : Callback<EmpleadosDataCollectionItem> {
            override fun onFailure(call: Call<EmpleadosDataCollectionItem>, t: Throwable) {
                onResult(null)
            }

            override fun onResponse(call: Call<EmpleadosDataCollectionItem>,
                                    response: Response<EmpleadosDataCollectionItem>) {
                if (response.isSuccessful) {
                    val addedEmpleado = response.body()!!
                    onResult(addedEmpleado)
                }
                /*else if (response.code() == 401){
                    Toast.makeText(this@MainActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }*/
                else if (response.code() == 500){
                    //val gson = Gson()
                    //val type = object : TypeToken<RestApiError>() {}.type
                    //var errorResponse1: RestApiError? = gson.fromJson(response.errorBody()!!.charStream(), type)
                    val errorResponse = Gson().fromJson(response.errorBody()!!.string()!!, RestApiError::class.java)

                    Toast.makeText(this@EmpleadosActivity,errorResponse.errorDetails,Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@EmpleadosActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }

        }
        )
    }
}