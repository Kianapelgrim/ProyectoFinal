package hn.edu.ujcv.clinicadental2.facturaDetalleProducto

class FacturaDetalleProductoDataCollecion : ArrayList<FacturaDetalleProductoDataCollecion>()

data class FacturaDetalleProductoDataCollecionItem(
    val codigoFactura: Long,
    val codigoProducto: Int,
    val cantidadProducto: Int,

)
