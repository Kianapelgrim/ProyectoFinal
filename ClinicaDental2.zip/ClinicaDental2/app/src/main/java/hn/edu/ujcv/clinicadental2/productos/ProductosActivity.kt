package hn.edu.ujcv.clinicadental2.productos

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import hn.edu.ujcv.clinicadental2.MainActivity
import hn.edu.ujcv.clinicadental2.R
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosDataCollectionItem
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosService
import hn.edu.ujcv.clinicadental2.empleados.RestEngine
import kotlinx.android.synthetic.main.activity_citas.*
import kotlinx.android.synthetic.main.activity_empleados.*
import kotlinx.android.synthetic.main.activity_empleados.btnAtras
import kotlinx.android.synthetic.main.activity_productos.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProductosActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_productos)
        btnAtras.setOnClickListener { val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)}
        btnBuscarIdProducto.setOnClickListener { v-> callServiceGetProducto() }
    }


    private fun callServiceGetProducto() {
        val productoService: ProductosService = RestEngine.buildService().create(ProductosService::class.java)
        var result: Call<ProductosDataCollectionItem> = productoService.getProductoById(txtCodigoProducto.text.toString().toLong())

        result.enqueue(object : Callback<ProductosDataCollectionItem> {
            override fun onFailure(call: Call<ProductosDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@ProductosActivity,"Error", Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<ProductosDataCollectionItem>,
                response: Response<ProductosDataCollectionItem>
            ) {

                txtNombreProducto.setText(response.body()!!.nombreProducto)
                txtDescripcion.setText(response.body()!!.descripcion)
                txtPrecio.setText(response.body()!!.precio.toString())
                txtStockActual.setText(response.body()!!.stockActual.toString())
                txtStockMinimo.setText(response.body()!!.stockMinimo.toString())
                txtStockMaximo.setText(response.body()!!.stockMaximo.toString())



                Toast.makeText(this@ProductosActivity,"OK"+response.body()!!.nombreProducto, Toast.LENGTH_LONG).show()
            }
        })
    }
}