package hn.edu.ujcv.clinicadental2.clinica
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface ClinicaService {
    @GET("clinicas")
    fun listClinicas(): Call<List<ClinicaDataCollecionItem>>
    @GET("clinicas/id/{id}")
    fun getClinicaById(@Path("id") id: Long): Call<ClinicaDataCollecionItem>
    @Headers("Content-Type: application/json")
    @POST("clinicas/addClinica")
    fun addClinica(@Body ClinicaData: ClinicaDataCollecionItem): Call<ClinicaDataCollecionItem>
    @Headers("Content-Type: application/json")
    @PUT("clinicas")
    fun updateClinica(@Body ClinicaData: ClinicaDataCollecionItem): Call<ClinicaDataCollecionItem>
    @DELETE("clinicas/delete/{id}")
    fun deleteClinica(@Path("id") id: Long): Call<ResponseBody>
}