package hn.edu.ujcv.clinicadental2.paciente

import java.util.*
import kotlin.collections.ArrayList

class PacienteDataCollection : ArrayList<PacienteDataCollection>()

data class PacienteDataCollectionItem(
    val codigoPaciente: Long,
    val nombre: String,
    val apellido: String,
    val telefono: Long,
    val email: String,
    val codigoDireccion: Long,
    val fechaDeRegistro: String,
    val fechaDeNacimiento: String,
)
