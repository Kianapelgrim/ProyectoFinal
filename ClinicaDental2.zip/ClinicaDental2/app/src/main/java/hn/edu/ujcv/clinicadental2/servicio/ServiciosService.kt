package hn.edu.ujcv.clinicadental2.servicio
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface ServiciosService {
    @GET("servicios")
    fun listServicios(): Call<List<ServicioDataCollectionItem>>
    @GET("servicios/id/{id}")
    fun getServicioById(@Path("id") id: Long): Call<ServicioDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("servicios/addServicio")
    fun addServicio(@Body ServicioData: ServicioDataCollectionItem): Call<ServicioDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("servicios")
    fun updateServicio(@Body ServiciosData: ServicioDataCollectionItem): Call<ServicioDataCollectionItem>
    @DELETE("servicios/delete/{id}")
    fun deleteServicio(@Path("id") id: Long): Call<ResponseBody>
}