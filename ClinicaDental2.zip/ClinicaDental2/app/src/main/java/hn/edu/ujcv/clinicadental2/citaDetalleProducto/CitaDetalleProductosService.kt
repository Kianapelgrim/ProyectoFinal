package hn.edu.ujcv.clinicadental2.citaDetalleProducto
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface CitaDetalleProductosService {
    @GET("citaDetalleProductos")
    fun listProductos(): Call<List<CitaDetalleProductosDataCollectionItem>>

    //Si da Error es porque es citaDetalleProductos/codigoServicio/

    @GET("citaDetalleProductos/id/{id}")
    fun getcitaDetalleProductoById(@Path("id") id: Long): Call<CitaDetalleProductosDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("citaDetalleProductos/addCitaDetalleProducto")
    fun addcitaDetalleProducto(@Body CitaDetalleProductoData: CitaDetalleProductosDataCollectionItem): Call<CitaDetalleProductosDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("citaDetalleProductos")
    fun updatecitaDetalleProducto(@Body CitaDetalleProductoData: CitaDetalleProductosDataCollectionItem): Call<CitaDetalleProductosDataCollectionItem>
    @DELETE("citaDetalleProductos/delete/{id}")
    fun deletecitaDetalleProducto(@Path("id") id: Long): Call<ResponseBody>
}