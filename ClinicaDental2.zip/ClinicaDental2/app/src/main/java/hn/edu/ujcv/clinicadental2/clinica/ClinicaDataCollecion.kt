package hn.edu.ujcv.clinicadental2.clinica

class ClinicaDataCollecion : ArrayList<ClinicaDataCollecion>()

data class ClinicaDataCollecionItem(
    val codigoClinica: Long?,
    val nombreClinica: String,
    val telefono: Int,
    val codigoDireccion: Int,
    val codigoEmpleado: Int,
)
