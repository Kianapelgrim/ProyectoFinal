package hn.edu.ujcv.clinicadental2.facturaDetalleProducto
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosDataCollectionItem
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface FacturaDetalleProductoService {
    @GET("facturaDetalleProductos")
    fun listFacturaDetalleProductos(): Call<List<FacturaDetalleProductoService>>
    @GET("facturaDetalleProductos/id/{id}")
    fun getFacturaDetalleProductoById(@Path("id") id: Long): Call<FacturaDetalleProductoService>
    @Headers("Content-Type: application/json")
    @POST("facturaDetalleProductos/addFacturaDetalleProducto")
    fun addFacturaDetalleProducto(@Body FacturaDetalleProductoData: FacturaDetalleProductoService): Call<FacturaDetalleProductoService>
    @Headers("Content-Type: application/json")
    @PUT("facturaDetalleProductos")
    fun updateFacturaDetalleProducto(@Body FacturaDetalleProductoData: FacturaDetalleProductoService): Call<FacturaDetalleProductoService>
    @DELETE("facturaDetalleProductos/delete/{id}")
    fun deleteFacturaDetalleProducto(@Path("id") id: Long): Call<ResponseBody>
}