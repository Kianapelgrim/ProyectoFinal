package hn.edu.ujcv.clinicadental2.cita

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.gson.Gson
import hn.edu.ujcv.clinicadental2.MainActivity
import hn.edu.ujcv.clinicadental2.R
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosDataCollectionItem
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosService
import hn.edu.ujcv.clinicadental2.empleados.RestEngine
import hn.edu.ujcv.clinicadental2.entities.RestApiError
import hn.edu.ujcv.clinicadental2.paciente.PacienteDataCollectionItem
import hn.edu.ujcv.clinicadental2.paciente.PacienteService
import kotlinx.android.synthetic.main.activity_citas.*
import kotlinx.android.synthetic.main.activity_citas.txtCodigoClinica
import kotlinx.android.synthetic.main.activity_clinicas.*
import kotlinx.android.synthetic.main.activity_empleados.*
import kotlinx.android.synthetic.main.activity_empleados.btnAtras
import kotlinx.android.synthetic.main.activity_pacientes.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import okhttp3.ResponseBody

class CitasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_citas)
        btnAtras.setOnClickListener { val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)}
        btnBuscarIdCita.setOnClickListener { v-> callServiceGetCita() }
        btnGuardarCita.setOnClickListener { v-> callServicePostCita() }
        btnEliminarCita.setOnClickListener { v-> callServiceDeleteCita() }
        btnActualizarCita.setOnClickListener { v->callServicePutCita() }

    }
    private fun callServiceGetCita() {
        val citaService: CitasService = RestEngine.buildService().create(CitasService::class.java)
        var result: Call<CitasDataCollectionItem> = citaService.getCitaById(txtCodigoCita.text.toString().toLong())

        result.enqueue(object : Callback<CitasDataCollectionItem> {
            override fun onFailure(call: Call<CitasDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@CitasActivity,"Error", Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<CitasDataCollectionItem>,
                response: Response<CitasDataCollectionItem>
            ) {
                if (response.code() == 404) {
                    txtEstado.setText(" 5")
                    txtFecha.setText(" ")
                    txtHora.setText(" ")
                    txtCodigoClinica.setText(" ")
                    txtCodigoPacienteC.setText(" ")
                    txtcodigoEmpleadoC.setText(" ")
                    txtFechaDeRegistro.setText(" ")
                    Toast.makeText(this@CitasActivity,"Esta Cita no exite",Toast.LENGTH_LONG).show()
                } else {
                txtEstado.setText(response.body()?.estado.toString())
                txtFecha.setText(response.body()!!.fecha.toString())
                txtHora.setText(response.body()!!.hora.toString())
                txtCodigoClinica.setText(response.body()!!.codigoClinica.toString())
                txtCodigoPacienteC.setText(response.body()!!.codigoPaciente)
                txtcodigoEmpleadoC.setText(response.body()!!.codigoEmpleado)
                txtFechaDeRegistro.setText(response.body()!!.fechaDeRegistro.toString())
                Toast.makeText(this@CitasActivity,"OK"+response.body()!!.estado, Toast.LENGTH_LONG).show()
                }
            }
        })
    }
    private fun callServicePostCita() {
        val CitaInfo = CitasDataCollectionItem(  codigoCita = txtCodigoCita.toString().toLong(),
            estado = txtEstado.text.toString(),
            fecha = txtFecha.text.toString(),
            hora = txtHora.text.toString(),
            codigoClinica = txtCodigoClinica.text.toString().toLong(),
            codigoPaciente = txtCodigoPacienteC.text.toString().toInt(),
            codigoEmpleado = txtCodigoEmpleadoC.text.toString().toInt(),
            fechaDeRegistro = txtFechaDeRegistro.text.toString()

        )
        addCita(CitaInfo) {
            if (it?.codigoCita != null) {
                Toast.makeText(this@CitasActivity,"OK"+it?.codigoCita,Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@CitasActivity,"Error",Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun callServicePutCita() {
        val CitaInfo = CitasDataCollectionItem(  codigoCita = txtCodigoCita.toString().toLong(),
            estado = txtEstado.text.toString(),
            fecha = txtFecha.text.toString(),
            hora = txtHora.text.toString(),
            codigoClinica = txtCodigoClinica.text.toString().toLong(),
            codigoPaciente = txtCodigoPacienteC.text.toString().toInt(),
            codigoEmpleado = txtCodigoEmpleadoC.text.toString().toInt(),
            fechaDeRegistro = txtFechaDeRegistro.text.toString()
        )

        val retrofit = RestEngine.buildService().create(CitasService::class.java)
        var result: Call<CitasDataCollectionItem> = retrofit.updateCita(CitaInfo)

        result.enqueue(object : Callback<CitasDataCollectionItem> {
            override fun onFailure(call: Call<CitasDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@CitasActivity,"Error",Toast.LENGTH_LONG).show()
            }

            override fun onResponse(call: Call<CitasDataCollectionItem>,
                                    response: Response<CitasDataCollectionItem>) {
                if (response.isSuccessful) {
                    val updatePaciente = response.body()!!
                    Toast.makeText(this@CitasActivity,"OK"+response.body()!!.estado,Toast.LENGTH_LONG).show()
                }
                else if (response.code() == 401){
                    Toast.makeText(this@CitasActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@CitasActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }

        })
    }
    fun addCita(citaData: CitasDataCollectionItem, onResult: (CitasDataCollectionItem?) -> Unit){
        val retrofit = RestEngine.buildService().create(CitasService::class.java)
        var result: Call<CitasDataCollectionItem> = retrofit.addCita(citaData)

        result.enqueue(object : Callback<CitasDataCollectionItem> {
            override fun onFailure(call: Call<CitasDataCollectionItem>, t: Throwable) {
                onResult(null)
            }

            override fun onResponse(call: Call<CitasDataCollectionItem>,
                                    response: Response<CitasDataCollectionItem>) {
                if (response.isSuccessful) {
                    val addedCita = response.body()!!
                    onResult(addedCita)
                }

                else if (response.code() == 500){

                    val errorResponse = Gson().fromJson(response.errorBody()!!.string()!!, RestApiError::class.java)

                    Toast.makeText(this@CitasActivity,errorResponse.errorDetails,Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@CitasActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }

        }
        )
    }
    private fun callServiceDeleteCita() {
        val citaService:CitasService = RestEngine.buildService().create(CitasService::class.java)
        var result: Call<ResponseBody> = citaService.deleteCita(txtCodigoCita.text.toString().toLong())

        result.enqueue(object :  Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(this@CitasActivity,"Error",Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<ResponseBody>,
                response: Response<ResponseBody>
            ) {
                if (response.isSuccessful) {
                    Toast.makeText(this@CitasActivity,"DELETE",Toast.LENGTH_LONG).show()
                }
                else if (response.code() == 401){
                    Toast.makeText(this@CitasActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@CitasActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }
        })
    }
}