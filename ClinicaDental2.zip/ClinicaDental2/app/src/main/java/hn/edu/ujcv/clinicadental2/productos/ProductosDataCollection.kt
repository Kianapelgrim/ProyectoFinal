package hn.edu.ujcv.clinicadental2.productos

class ProductosDataCollection : ArrayList<ProductosDataCollection>()

data class ProductosDataCollectionItem(
    val codigoProducto: Long?,
    val nombreProducto: String,
    val descripcion: String,
    val precio: Float,
    val stockActual: Int,
    val stockMinimo: Int,
    val stockMaximo: Int,

)
