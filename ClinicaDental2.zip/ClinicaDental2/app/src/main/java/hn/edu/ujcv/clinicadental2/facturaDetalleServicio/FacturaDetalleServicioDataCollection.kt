package hn.edu.ujcv.clinicadental2.facturaDetalleServicio

class FacturaDetalleServicioDataCollection : ArrayList<FacturaDetalleServicioDataCollection>()

data class FacturaDetalleServicioDataCollectionItem(
    val codigoFactura: Long,
    val codigoServicio: Int,

)
