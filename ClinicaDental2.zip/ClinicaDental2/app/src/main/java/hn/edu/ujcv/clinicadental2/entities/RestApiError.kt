package hn.edu.ujcv.clinicadental2.entities

data class RestApiError(val httpStatus: String, val errorMessage: String, val errorDetails: String) {
}