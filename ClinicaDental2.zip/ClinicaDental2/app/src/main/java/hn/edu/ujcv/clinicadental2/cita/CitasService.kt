package hn.edu.ujcv.clinicadental2.cita
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface CitasService {
    @GET("citas")
    fun listCitas(): Call<List<CitasDataCollectionItem>>
    @GET("citas/id/{id}")
    fun getCitaById(@Path("id") id: Long): Call<CitasDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("citas/addCita")
    fun addCita(@Body CitasData: CitasDataCollectionItem): Call<CitasDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("citas")
    fun updateCita(@Body CitasData: CitasDataCollectionItem): Call<CitasDataCollectionItem>
    @DELETE("citas/delete/{id}")
    fun deleteCita(@Path("id") id: Long): Call<ResponseBody>
}