package hn.edu.ujcv.clinicadental2.factura

import java.time.LocalTime
import java.util.*
import kotlin.collections.ArrayList

class FacturaDataCollecion : ArrayList<FacturaDataCollecion>()

data class FacturaDataCollecionItem(
    val codigoFactura: Long,
    val codigoEmpleado: Int,
    val codigoPaciente: Int,
    val codigoCita: Int,
    val cai: String,
    val fechaDeRealizacion: Date,
    val horaDeRealizacion: LocalTime,
    val fechaDeVencimiento: Date,
    val precioTotal: Float,
)
