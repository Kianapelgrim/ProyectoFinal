package hn.edu.ujcv.clinicadental2.paciente

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.gson.Gson
import hn.edu.ujcv.clinicadental2.MainActivity
import hn.edu.ujcv.clinicadental2.R
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosDataCollectionItem
import hn.edu.ujcv.clinicadental2.empleados.EmpleadosService
import hn.edu.ujcv.clinicadental2.empleados.RestEngine
import hn.edu.ujcv.clinicadental2.entities.RestApiError
import kotlinx.android.synthetic.main.activity_empleados.*
import kotlinx.android.synthetic.main.activity_pacientes.*
import kotlinx.android.synthetic.main.activity_pacientes.btnAtras
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PacientesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pacientes)
        btnAtras.setOnClickListener { val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)}
        btnBuscarIdPaciente.setOnClickListener { v-> callServiceGetPaciente() }
        btnGuardarPaciente.setOnClickListener { callServicePostPaciente() }
        btnEliminarPaciente.setOnClickListener { callServiceDeletePaciente() }
        btnActualizarPaciente.setOnClickListener { callServicePutPaciente() }


    }
    private fun callServiceGetPaciente() {
        val pacienteService: PacienteService = RestEngine.buildService().create(PacienteService::class.java)
        var result: Call<PacienteDataCollectionItem> = pacienteService.getPacienteById(txtCodigoPaciente.text.toString().toLong())

        result.enqueue(object : Callback<PacienteDataCollectionItem> {
            override fun onFailure(call: Call<PacienteDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@PacientesActivity,"Error", Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<PacienteDataCollectionItem>,
                response: Response<PacienteDataCollectionItem>
            ) {
                if (response.code() == 404) {
                    txtNombrePaciente.setText("")
                    txtApellidoPaciente.setText("")
                    txtTelefonoPaciente.setText("")
                    txtEmailPaciente.setText("")
                    txtCodigoDireccion.setText("")
                    txtFechaDeRegistroPaciente.setText("")
                    txtFechaDeNacimientoPaciente.setText("")
                    Toast.makeText(this@PacientesActivity,"Este Paciente no exite",Toast.LENGTH_LONG).show()
                } else {
                    txtNombrePaciente.setText(response.body()!!.nombre)
                    txtApellidoPaciente.setText(response.body()!!.apellido)
                    txtTelefonoPaciente.setText(response.body()!!.telefono.toString())
                    txtEmailPaciente.setText(response.body()!!.email)
                    txtCodigoDireccion.setText(response.body()!!.codigoDireccion.toString())
                    txtFechaDeRegistroPaciente.setText(response.body()!!.fechaDeRegistro.toString())
                    txtFechaDeNacimientoPaciente.setText(response.body()!!.fechaDeNacimiento.toString())
                    Toast.makeText(this@PacientesActivity,"OK"+response.body()!!.nombre, Toast.LENGTH_LONG).show()            }

            }
        })
    }
    private fun callServicePostPaciente() {
        val PacienteInfo = PacienteDataCollectionItem(  codigoPaciente = txtCodigoPaciente.text.toString().toLong(),
            nombre = txtNombrePaciente.text.toString(),
            apellido = txtApellidoPaciente.text.toString(),
            telefono = txtTelefonoPaciente.text.toString().toLong(),
            email = txtEmailPaciente.text.toString(),
            fechaDeRegistro = txtFechaDeRegistroPaciente.text.toString(),
            fechaDeNacimiento = txtFechaDeNacimientoPaciente.text.toString(),
            codigoDireccion = 12

        )
        addPaciente(PacienteInfo) {
            if (it?.codigoPaciente != null) {
                Toast.makeText(this@PacientesActivity,"OK"+it?.codigoPaciente,Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this@PacientesActivity,"Error",Toast.LENGTH_LONG).show()
            }
        }
    }
    fun addPaciente(pacienteData: PacienteDataCollectionItem, onResult: (PacienteDataCollectionItem?) -> Unit){
        val retrofit = RestEngine.buildService().create(PacienteService::class.java)
        var result: Call<PacienteDataCollectionItem> = retrofit.addPaciente(pacienteData)

        result.enqueue(object : Callback<PacienteDataCollectionItem> {
            override fun onFailure(call: Call<PacienteDataCollectionItem>, t: Throwable) {
                onResult(null)
            }

            override fun onResponse(call: Call<PacienteDataCollectionItem>,
                                    response: Response<PacienteDataCollectionItem>) {
                if (response.isSuccessful) {
                    val addedPaciente = response.body()!!
                    onResult(addedPaciente)
                }
                /*else if (response.code() == 401){
                    Toast.makeText(this@MainActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }*/
                else if (response.code() == 500){
                    //val gson = Gson()
                    //val type = object : TypeToken<RestApiError>() {}.type
                    //var errorResponse1: RestApiError? = gson.fromJson(response.errorBody()!!.charStream(), type)
                    val errorResponse = Gson().fromJson(response.errorBody()!!.string()!!, RestApiError::class.java)

                    Toast.makeText(this@PacientesActivity,errorResponse.errorDetails,Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@PacientesActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }

        }
        )
    }
    private fun callServicePutPaciente() {
        val PacienteInfo = PacienteDataCollectionItem(  codigoPaciente = txtCodigoPaciente.text.toString().toLong(),
            nombre = txtNombrePaciente.text.toString(),
            apellido = txtApellidoPaciente.text.toString(),
            telefono = txtTelefonoPaciente.text.toString().toLong(),
            email = txtEmailPaciente.text.toString(),
            fechaDeRegistro = txtFechaDeRegistroPaciente.text.toString(),
            fechaDeNacimiento = txtFechaDeNacimientoPaciente.text.toString(),
            codigoDireccion = 12
        )

        val retrofit = RestEngine.buildService().create(PacienteService::class.java)
        var result: Call<PacienteDataCollectionItem> = retrofit.updatePaciente(PacienteInfo)

        result.enqueue(object : Callback<PacienteDataCollectionItem> {
            override fun onFailure(call: Call<PacienteDataCollectionItem>, t: Throwable) {
                Toast.makeText(this@PacientesActivity,"Error",Toast.LENGTH_LONG).show()
            }

            override fun onResponse(call: Call<PacienteDataCollectionItem>,
                                    response: Response<PacienteDataCollectionItem>) {
                if (response.isSuccessful) {
                    val updatePaciente = response.body()!!
                    Toast.makeText(this@PacientesActivity,"OK"+response.body()!!.nombre,Toast.LENGTH_LONG).show()
                }
                else if (response.code() == 401){
                    Toast.makeText(this@PacientesActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@PacientesActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }

        })
    }
    private fun callServiceDeletePaciente() {
        val pacienteService:PacienteService = RestEngine.buildService().create(PacienteService::class.java)
        var result: Call<ResponseBody> = pacienteService.deletePaciente(txtCodigoPaciente.text.toString().toLong())

        result.enqueue(object :  Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(this@PacientesActivity,"Error",Toast.LENGTH_LONG).show()
            }

            override fun onResponse(
                call: Call<ResponseBody>,
                response: Response<ResponseBody>
            ) {
                if (response.isSuccessful) {
                    Toast.makeText(this@PacientesActivity,"DELETE",Toast.LENGTH_LONG).show()
                }
                else if (response.code() == 401){
                    Toast.makeText(this@PacientesActivity,"Sesion expirada",Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@PacientesActivity,"Fallo al traer el item",Toast.LENGTH_LONG).show()
                }
            }
        })
    }
}