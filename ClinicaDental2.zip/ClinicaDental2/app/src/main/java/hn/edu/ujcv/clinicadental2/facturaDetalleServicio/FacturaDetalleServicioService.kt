package hn.edu.ujcv.clinicadental2.facturaDetalleServicio
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface FacturaDetalleServicioService {
    @GET("facturaDetalleServicios")
    fun listFacturaDetalleServicios(): Call<List<FacturaDetalleServicioDataCollectionItem>>
    @GET("facturaDetalleServicios/id/{id}")
    fun getFacturaDetalleServicioById(@Path("id") id: Long): Call<FacturaDetalleServicioDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("facturaDetalleServicios/FacturaDetalleServicio")
    fun addFacturaDetalleServicio(@Body FacturaDetalleServicioData: FacturaDetalleServicioDataCollectionItem): Call<FacturaDetalleServicioDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("facturaDetalleServicios")
    fun updateFacturaDetalleServicio(@Body FacturaDetalleServicioData: FacturaDetalleServicioDataCollectionItem): Call<FacturaDetalleServicioDataCollectionItem>
    @DELETE("facturaDetalleServicios/delete/{id}")
    fun deleteFacturaDetalleServicio(@Path("id") id: Long): Call<ResponseBody>
}