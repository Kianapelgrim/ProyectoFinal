package hn.edu.ujcv.clinicadental2.direccion

class DireccionDataCollection : ArrayList<DireccionDataCollection>()

data class DireccionDataCollectionItem(
    val codigoDireccion: Long,
    val ciudad: String,
    val calle: String,
    val zipCode: Int,
    val departamentos: String,
)
