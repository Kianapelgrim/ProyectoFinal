package hn.edu.ujcv.clinicadental2.citaDetalleProducto

class CitaDetalleProductosDataCollection : ArrayList<CitaDetalleProductosDataCollection>()

data class CitaDetalleProductosDataCollectionItem(
    val codigoCita: Long?,
    val codigoServicio: Int,

)
