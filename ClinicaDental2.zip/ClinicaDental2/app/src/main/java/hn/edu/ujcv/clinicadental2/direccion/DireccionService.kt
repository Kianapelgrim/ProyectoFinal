package hn.edu.ujcv.clinicadental2.direccion
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*


interface DireccionService {
    @GET("direccions")
    fun listDireccions(): Call<List<DireccionDataCollectionItem>>
    @GET("direccions/id/{id}")
    fun getDireccionById(@Path("id") id: Long): Call<DireccionDataCollectionItem>
    @Headers("Content-Type: application/json")
    @POST("direccions/addDireccion")
    fun addDireccion(@Body DireccionData: DireccionDataCollectionItem): Call<DireccionDataCollectionItem>
    @Headers("Content-Type: application/json")
    @PUT("direccions")
    fun updateDireccion(@Body DireccionData: DireccionDataCollectionItem): Call<DireccionDataCollectionItem>
    @DELETE("direccions/delete/{id}")
    fun deleteDireccion(@Path("id") id: Long): Call<ResponseBody>
}